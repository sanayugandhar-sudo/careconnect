export type Gender = 'Male' | 'Female' | 'Other';

export type RegistrationType = 'online' | 'walk-in';

export type RegistrationStatus =
  | 'Registered'
  | 'Waiting'
  | 'In Consultation'
  | 'Completed'
  | 'Cancelled';

export type PaymentStatus = 'Pending' | 'Paid at Counter' | 'Online Confirmed';

export interface HospitalInfo {
  name: string;
  tagline: string;
  address: string;
  cityStateZip: string;
  helpline: string;
  emergency: string;
  email: string;
  opdHours: string;
  counterLocations: string;
}

export interface Department {
  id: string;
  name: string;
  code: string;
  description: string;
  floor: string;
  wing: string;
  headDoctor: string;
  iconName: string;
  active: boolean;
}

export interface Doctor {
  id: string;
  name: string;
  qualification: string;
  departmentId: string;
  departmentName: string;
  specialization: string;
  experienceYears: number;
  roomNumber: string;
  floor: string;
  consultationFee: number;
  opdDays: string[];
  opdTimings: string;
  availableSlots: string[];
  isAvailable: boolean;
  avatarUrl?: string;
}

export interface Patient {
  id: string;
  fullName: string;
  age: number;
  gender: Gender;
  mobileNumber: string;
  address: string;
  bloodGroup?: string;
  emergencyContact?: string;
  createdAt: string;
}

export interface OPRegistration {
  id: string;
  opNumber: string;
  tokenNumber: number;
  patientId: string;
  patientName: string;
  age: number;
  gender: Gender;
  mobileNumber: string;
  address: string;
  departmentId: string;
  departmentName: string;
  doctorId: string;
  doctorName: string;
  roomNumber: string;
  floor: string;
  registrationType: RegistrationType;
  appointmentDate: string; // YYYY-MM-DD
  appointmentTime: string; // e.g. "09:30 AM"
  registrationDate: string; // ISO string
  status: RegistrationStatus;
  consultationFee: number;
  paymentStatus: PaymentStatus;
  symptomsNotes?: string;
  registeredBy: 'patient_self' | 'receptionist' | 'admin';
  isDemo: boolean;
  arrivedAt?: string;
  completedAt?: string;
}

export type UserRole = 'patient' | 'receptionist' | 'admin';

export interface StaffUser {
  id: string;
  name: string;
  email: string;
  role: 'receptionist' | 'admin';
  departmentAssigned?: string;
}

export interface AISymptomSuggestion {
  suggestedDepartment: string;
  matchedDepartmentId: string;
  explanation: string;
  suggestedQuestions: string[];
  isUrgentCareNeeded: boolean;
  urgencyWarning?: string;
  disclaimer: string;
}

export interface DashboardStats {
  totalRegistrations: number;
  todayRegistrations: number;
  onlineRegistrations: number;
  walkinRegistrations: number;
  waitingCount: number;
  inConsultationCount: number;
  completedCount: number;
  cancelledCount: number;
  departmentCounts: { departmentId: string; departmentName: string; count: number }[];
  doctorQueues: {
    doctorId: string;
    doctorName: string;
    departmentName: string;
    roomNumber: string;
    totalToday: number;
    waiting: number;
    inConsultation: number;
    completed: number;
    currentToken?: number;
  }[];
}
