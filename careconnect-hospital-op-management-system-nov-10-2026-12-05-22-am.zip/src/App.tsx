import React, { useState, useEffect } from 'react';
import { api } from './api';
import {
  Department,
  Doctor,
  HospitalInfo,
  OPRegistration,
  StaffUser,
} from './types/index';
import { Header } from './components/Header';
import { DemoNoticeBanner } from './components/DemoNoticeBanner';
import { HospitalHero } from './components/HospitalHero';
import { PatientBookingForm } from './components/PatientPortal/PatientBookingForm';
import { DepartmentDirectory } from './components/DepartmentDirectory';
import { ReceptionCounter } from './components/ReceptionPortal/ReceptionCounter';
import { AdminDashboard } from './components/AdminPortal/AdminDashboard';
import { LiveQueueBoard } from './components/LiveQueueBoard';
import { OPSlipModal } from './components/OPSlipModal';
import { AuthModal } from './components/AuthModal';
import { PatientLookupModal } from './components/PatientPortal/PatientLookupModal';
import { SymptomAssistantModal } from './components/PatientPortal/SymptomAssistantModal';
import { Building2, Phone, Mail, ShieldAlert, Heart, Calendar } from 'lucide-react';

export default function App() {
  const [activeView, setActiveView] = useState<'patient' | 'reception' | 'admin' | 'queue'>('patient');

  // Core Data
  const [hospitalInfo, setHospitalInfo] = useState<HospitalInfo | null>(null);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [currentUser, setCurrentUser] = useState<StaffUser | null>(null);

  // Modals
  const [activeRegistrationSlip, setActiveRegistrationSlip] = useState<OPRegistration | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showLookupModal, setShowLookupModal] = useState(false);
  const [showAiModal, setShowAiModal] = useState(false);

  const [bookingSectionRef, setBookingSectionRef] = useState<HTMLDivElement | null>(null);

  // Load Initial Hospital Data & Auth State
  const loadInitialData = async () => {
    try {
      const [hInfo, depts, docs, me] = await Promise.all([
        api.getHospitalInfo(),
        api.getDepartments(),
        api.getDoctors(),
        api.getMe(),
      ]);
      setHospitalInfo(hInfo);
      setDepartments(depts);
      setDoctors(docs);
      if (me) setCurrentUser(me);
    } catch (err) {
      console.error('Failed to load initial data:', err);
    }
  };

  useEffect(() => {
    loadInitialData();
  }, []);

  const handleLogout = async () => {
    await api.logout();
    setCurrentUser(null);
    if (activeView === 'reception' || activeView === 'admin') {
      setActiveView('patient');
    }
  };

  const handleQuickSwitchRole = async (role: 'patient' | 'receptionist' | 'admin') => {
    if (role === 'patient') {
      await api.logout();
      setCurrentUser(null);
      setActiveView('patient');
    } else if (role === 'receptionist') {
      try {
        const res = await api.login('receptionist@careconnect.org', 'rec123');
        setCurrentUser(res.user);
        setActiveView('reception');
      } catch (err) {
        console.error(err);
      }
    } else if (role === 'admin') {
      try {
        const res = await api.login('admin@careconnect.org', 'admin123');
        setCurrentUser(res.user);
        setActiveView('admin');
      } catch (err) {
        console.error(err);
      }
    }
  };

  const scrollToBooking = () => {
    setActiveView('patient');
    if (bookingSectionRef) {
      bookingSectionRef.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-800 selection:bg-sky-500 selection:text-white">
      {/* Top Demo Notice Banner with Quick Role Testing Chips */}
      <DemoNoticeBanner
        currentUser={currentUser}
        onQuickSwitchRole={handleQuickSwitchRole}
      />

      {/* Header with Top Bar Contract */}
      <Header
        hospitalInfo={hospitalInfo}
        activeView={activeView}
        setActiveView={(v) => {
          // If accessing reception or admin without auth, open auth modal
          if (v === 'reception' && !currentUser) {
            setShowAuthModal(true);
            return;
          }
          if (v === 'admin' && currentUser?.role !== 'admin') {
            setShowAuthModal(true);
            return;
          }
          setActiveView(v);
        }}
        currentUser={currentUser}
        onOpenAuth={() => setShowAuthModal(true)}
        onOpenLookup={() => setShowLookupModal(true)}
        onLogout={handleLogout}
      />

      {/* Main Viewport Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 md:px-8 py-6 md:py-8 space-y-8">
        {/* VIEW 1: PATIENT PORTAL */}
        {activeView === 'patient' && (
          <div className="space-y-8">
            {/* Hospital Hero Banner with Generated Imagery */}
            <HospitalHero
              hospitalInfo={hospitalInfo}
              onStartBooking={scrollToBooking}
              onOpenLookup={() => setShowLookupModal(true)}
              onOpenAi={() => setShowAiModal(true)}
            />

            {/* Department Directory & Facilities */}
            <DepartmentDirectory
              departments={departments}
              doctors={doctors}
              onSelectDepartment={(deptId) => {
                scrollToBooking();
              }}
            />

            {/* Patient Booking Form Section */}
            <div ref={(el) => setBookingSectionRef(el)} id="booking-section">
              <PatientBookingForm
                hospitalInfo={hospitalInfo}
                departments={departments}
                onRegistrationSuccess={(reg) => {
                  setActiveRegistrationSlip(reg);
                }}
              />
            </div>
          </div>
        )}

        {/* VIEW 2: RECEPTION COUNTER PORTAL */}
        {activeView === 'reception' && (
          <div>
            {currentUser && (currentUser.role === 'receptionist' || currentUser.role === 'admin') ? (
              <ReceptionCounter
                currentUser={currentUser}
                departments={departments}
                onPrintSlip={(reg) => setActiveRegistrationSlip(reg)}
                onLogout={handleLogout}
              />
            ) : (
              <div className="bg-white rounded-2xl p-8 border border-slate-200 text-center max-w-md mx-auto space-y-4">
                <Building2 className="w-12 h-12 text-sky-700 mx-auto" />
                <h3 className="text-lg font-bold text-slate-900">Hospital Receptionist Access Required</h3>
                <p className="text-xs text-slate-500">
                  Please log in with staff credentials to operate the walk-in registration counter and manage today's OPD queue.
                </p>
                <div className="pt-2">
                  <button
                    onClick={() => setShowAuthModal(true)}
                    className="w-full py-2.5 bg-sky-700 hover:bg-sky-600 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
                  >
                    Open Staff Sign In
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* VIEW 3: ADMIN DASHBOARD */}
        {activeView === 'admin' && (
          <div>
            {currentUser && currentUser.role === 'admin' ? (
              <AdminDashboard
                currentUser={currentUser}
                departments={departments}
                doctors={doctors}
                onRefreshData={loadInitialData}
                onPrintSlip={(reg) => setActiveRegistrationSlip(reg)}
                onLogout={handleLogout}
              />
            ) : (
              <div className="bg-white rounded-2xl p-8 border border-slate-200 text-center max-w-md mx-auto space-y-4">
                <ShieldAlert className="w-12 h-12 text-emerald-700 mx-auto" />
                <h3 className="text-lg font-bold text-slate-900">Medical Administration Privileges Required</h3>
                <p className="text-xs text-slate-500">
                  Sign in with an Administrator account to view hospital KPI analytics, manage patient queues, and adjust doctor rosters.
                </p>
                <div className="pt-2">
                  <button
                    onClick={() => setShowAuthModal(true)}
                    className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
                  >
                    Admin Sign In
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* VIEW 4: PUBLIC LIVE QUEUE BOARD */}
        {activeView === 'queue' && <LiveQueueBoard />}
      </main>

      {/* Hospital Footer */}
      <footer className="no-print bg-slate-900 text-slate-400 text-xs border-t border-slate-800 mt-12 py-8 px-4 md:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-6 pb-6 border-b border-slate-800">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-white font-bold text-sm">
              <span className="w-6 h-6 rounded bg-sky-600 flex items-center justify-center text-xs">C+</span>
              <span>CareConnect Multispeciality Hospital</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Leading tertiary healthcare medical center providing patient-first outpatient and emergency consultation services.
            </p>
          </div>

          <div>
            <span className="font-semibold text-slate-200 text-xs block mb-2 uppercase tracking-wider">
              OPD Timings
            </span>
            <div className="text-[11px] space-y-1 text-slate-400">
              <p>Monday - Saturday: 8:30 AM - 8:00 PM</p>
              <p>Sunday Clinic: 9:00 AM - 1:00 PM</p>
              <p className="text-rose-400 font-semibold mt-1">24x7 Trauma & Emergency Center Open</p>
            </div>
          </div>

          <div>
            <span className="font-semibold text-slate-200 text-xs block mb-2 uppercase tracking-wider">
              Emergency & Support
            </span>
            <div className="text-[11px] space-y-1 text-slate-400">
              <p className="flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-rose-400" />
                <span>Emergency: 108 / 040-6789-9999</span>
              </p>
              <p className="flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-slate-400" />
                <span>reception@careconnect-demo.org</span>
              </p>
              <p>Ground Floor Main Lobby, Counters 1–4</p>
            </div>
          </div>

          <div>
            <span className="font-semibold text-slate-200 text-xs block mb-2 uppercase tracking-wider">
              System Notice
            </span>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              DEMONSTRATION PROTOTYPE: Built as a simulated OP registration and management portal. No real hospital affiliation or official medical liability is implied.
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto pt-4 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-2">
          <div>© {new Date().getFullYear()} CareConnect Hospital OP Management System · All rights reserved</div>
          <div className="flex items-center gap-4">
            <span>Patient Privacy Protected</span>
            <span>·</span>
            <span>Continuous Atomic Token Sequence</span>
          </div>
        </div>
      </footer>

      {/* OP Slip Modal */}
      <OPSlipModal
        registration={activeRegistrationSlip}
        hospitalInfo={hospitalInfo}
        onClose={() => setActiveRegistrationSlip(null)}
      />

      {/* Staff Authentication Modal */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onLoginSuccess={(user) => {
          setCurrentUser(user);
          if (user.role === 'admin') setActiveView('admin');
          else setActiveView('reception');
        }}
      />

      {/* Patient Lookup Modal */}
      <PatientLookupModal
        isOpen={showLookupModal}
        onClose={() => setShowLookupModal(false)}
        onViewSlip={(reg) => {
          setShowLookupModal(false);
          setActiveRegistrationSlip(reg);
        }}
      />

      {/* AI Symptom Assistant Modal */}
      <SymptomAssistantModal
        isOpen={showAiModal}
        onClose={() => setShowAiModal(false)}
        onSelectDepartment={(deptId) => {
          scrollToBooking();
        }}
      />
    </div>
  );
}
