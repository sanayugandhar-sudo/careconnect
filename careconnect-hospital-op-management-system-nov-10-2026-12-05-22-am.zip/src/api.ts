import {
  Department,
  Doctor,
  HospitalInfo,
  OPRegistration,
  Patient,
  StaffUser,
  DashboardStats,
  RegistrationStatus,
  AISymptomSuggestion,
} from './types/index';

const TOKEN_KEY = 'careconnect_staff_token';

export const api = {
  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  },

  setToken(token: string) {
    localStorage.setItem(TOKEN_KEY, token);
  },

  clearToken() {
    localStorage.removeItem(TOKEN_KEY);
  },

  async fetchWithAuth(url: string, options: RequestInit = {}) {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...((options.headers as Record<string, string>) || {}),
    };

    const token = this.getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const res = await fetch(url, { ...options, headers });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || `HTTP ${res.status}: Failed to process request`);
    }
    return data;
  },

  async getHospitalInfo(): Promise<HospitalInfo> {
    const res = await fetch('/api/hospital-info');
    return res.json();
  },

  async getDepartments(): Promise<Department[]> {
    const res = await fetch('/api/departments');
    return res.json();
  },

  async getDoctors(departmentId?: string): Promise<Doctor[]> {
    const url = departmentId
      ? `/api/doctors?departmentId=${encodeURIComponent(departmentId)}`
      : '/api/doctors';
    const res = await fetch(url);
    return res.json();
  },

  async getDoctorSlots(doctorId: string, date: string): Promise<{ time: string; isBooked: boolean }[]> {
    const res = await fetch(
      `/api/doctors/slots?doctorId=${encodeURIComponent(doctorId)}&date=${encodeURIComponent(date)}`
    );
    const data = await res.json();
    return data.slots || [];
  },

  async registerOnline(patientData: {
    fullName: string;
    age: number;
    gender: 'Male' | 'Female' | 'Other';
    mobileNumber: string;
    address: string;
    bloodGroup?: string;
    departmentId: string;
    doctorId: string;
    appointmentDate: string;
    appointmentTime: string;
    symptomsNotes?: string;
  }): Promise<{ registration: OPRegistration; message: string }> {
    const res = await fetch('/api/registrations/online', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patientData),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to complete registration');
    return data;
  },

  async lookupRegistration(opNumber: string, mobileNumber: string): Promise<OPRegistration> {
    const res = await fetch('/api/registrations/lookup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ opNumber, mobileNumber }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Record not found');
    return data.registration;
  },

  async getAISymptomSuggestion(
    symptoms: string,
    age?: number,
    gender?: string
  ): Promise<AISymptomSuggestion> {
    const res = await fetch('/api/ai/suggest-department', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ symptoms, age, gender }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'AI suggestion unavailable');
    return data;
  },

  async login(email: string, passwordPlain: string): Promise<{ user: StaffUser; token: string }> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password: passwordPlain }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Login failed');
    this.setToken(data.token);
    return data;
  },

  async getMe(): Promise<StaffUser | null> {
    try {
      const data = await this.fetchWithAuth('/api/auth/me');
      return data.user || null;
    } catch {
      this.clearToken();
      return null;
    }
  },

  async logout(): Promise<void> {
    try {
      await this.fetchWithAuth('/api/auth/logout', { method: 'POST' });
    } catch {
      // ignore
    } finally {
      this.clearToken();
    }
  },

  async searchPatients(q: string): Promise<Patient[]> {
    return this.fetchWithAuth(`/api/patients/search?q=${encodeURIComponent(q)}`);
  },

  async registerWalkIn(walkinData: {
    fullName: string;
    age: number;
    gender: 'Male' | 'Female' | 'Other';
    mobileNumber: string;
    address: string;
    bloodGroup?: string;
    departmentId: string;
    doctorId: string;
    appointmentDate: string;
    appointmentTime: string;
    symptomsNotes?: string;
    initialStatus?: RegistrationStatus;
  }): Promise<{ registration: OPRegistration; message: string }> {
    return this.fetchWithAuth('/api/registrations/walk-in', {
      method: 'POST',
      body: JSON.stringify(walkinData),
    });
  },

  async getRegistrations(filters?: {
    date?: string;
    departmentId?: string;
    doctorId?: string;
    status?: RegistrationStatus;
    type?: 'online' | 'walk-in';
    search?: string;
  }): Promise<OPRegistration[]> {
    const params = new URLSearchParams();
    if (filters?.date) params.set('date', filters.date);
    if (filters?.departmentId) params.set('departmentId', filters.departmentId);
    if (filters?.doctorId) params.set('doctorId', filters.doctorId);
    if (filters?.status) params.set('status', filters.status);
    if (filters?.type) params.set('type', filters.type);
    if (filters?.search) params.set('search', filters.search);

    return this.fetchWithAuth(`/api/registrations?${params.toString()}`);
  },

  async updateRegistrationStatus(id: string, status: RegistrationStatus): Promise<OPRegistration> {
    const res = await this.fetchWithAuth(`/api/registrations/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
    return res.registration;
  },

  async getDashboardStats(): Promise<DashboardStats> {
    return this.fetchWithAuth('/api/dashboard/stats');
  },

  async addDoctor(doctorData: any): Promise<{ success: boolean; doctor: Doctor }> {
    return this.fetchWithAuth('/api/admin/doctors', {
      method: 'POST',
      body: JSON.stringify(doctorData),
    });
  },

  async updateDoctor(id: string, updates: Partial<Doctor>): Promise<{ success: boolean; doctor: Doctor }> {
    return this.fetchWithAuth(`/api/admin/doctors/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(updates),
    });
  },

  async deleteDoctor(id: string): Promise<void> {
    await this.fetchWithAuth(`/api/admin/doctors/${id}`, {
      method: 'DELETE',
    });
  },

  async addDepartment(deptData: any): Promise<{ success: boolean; department: Department }> {
    return this.fetchWithAuth('/api/admin/departments', {
      method: 'POST',
      body: JSON.stringify(deptData),
    });
  },

  async updateDepartment(id: string, updates: Partial<Department>): Promise<{ success: boolean; department: Department }> {
    return this.fetchWithAuth(`/api/admin/departments/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(updates),
    });
  },

  async deleteDepartment(id: string): Promise<void> {
    await this.fetchWithAuth(`/api/admin/departments/${id}`, {
      method: 'DELETE',
    });
  },

  async getLiveQueue(): Promise<any[]> {
    const res = await fetch('/api/live-queue');
    return res.json();
  },

  async resetDemo(): Promise<void> {
    await this.fetchWithAuth('/api/admin/reset-demo', { method: 'POST' });
  },
};
