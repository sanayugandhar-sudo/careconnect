import React, { useState, useEffect } from 'react';
import {
  UserCheck,
  Search,
  UserPlus,
  Printer,
  Clock,
  CheckCircle2,
  AlertCircle,
  Building2,
  Stethoscope,
  Filter,
  RefreshCw,
  FileText,
  ArrowRight,
  Shield,
  Layers,
} from 'lucide-react';
import { api } from '../../api';
import {
  Department,
  Doctor,
  Gender,
  OPRegistration,
  Patient,
  RegistrationStatus,
  StaffUser,
} from '../../types/index';

interface ReceptionCounterProps {
  currentUser: StaffUser;
  departments: Department[];
  onPrintSlip: (registration: OPRegistration) => void;
  onLogout: () => void;
}

export const ReceptionCounter: React.FC<ReceptionCounterProps> = ({
  currentUser,
  departments,
  onPrintSlip,
  onLogout,
}) => {
  const [activeTab, setActiveTab] = useState<'walkin' | 'queue'>('walkin');

  // Existing Patient Search to avoid duplicates
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Patient[]>([]);
  const [searchingPatient, setSearchingPatient] = useState(false);
  const [selectedExistingPatient, setSelectedExistingPatient] = useState<Patient | null>(null);

  // Walk-in Registration Form Fields
  const [fullName, setFullName] = useState('');
  const [age, setAge] = useState<number | ''>('');
  const [gender, setGender] = useState<Gender>('Male');
  const [mobileNumber, setMobileNumber] = useState('');
  const [address, setAddress] = useState('');
  const [bloodGroup, setBloodGroup] = useState('');

  const [selectedDeptId, setSelectedDeptId] = useState<string>(departments[0]?.id || '');
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>('');
  const [symptomsNotes, setSymptomsNotes] = useState('');

  // Queue state
  const [registrations, setRegistrations] = useState<OPRegistration[]>([]);
  const [loadingQueue, setLoadingQueue] = useState(false);
  const [queueStatusFilter, setQueueStatusFilter] = useState<string>('all');
  const [queueSearch, setQueueSearch] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Load doctors for chosen department
  useEffect(() => {
    if (!selectedDeptId) return;
    let isMounted = true;
    api
      .getDoctors(selectedDeptId)
      .then((docs) => {
        if (isMounted) {
          setDoctors(docs);
          if (docs.length > 0) setSelectedDoctorId(docs[0].id);
        }
      })
      .catch((err) => console.error(err));
    return () => {
      isMounted = false;
    };
  }, [selectedDeptId]);

  // Load active registrations
  const fetchQueue = async () => {
    setLoadingQueue(true);
    try {
      const today = new Date().toISOString().split('T')[0];
      const list = await api.getRegistrations({ date: today });
      setRegistrations(list);
    } catch (err: any) {
      console.error('Failed to load queue:', err);
    } finally {
      setLoadingQueue(false);
    }
  };

  useEffect(() => {
    fetchQueue();
    const interval = setInterval(fetchQueue, 15000);
    return () => clearInterval(interval);
  }, []);

  // Search existing patients when typing in patient search
  const handlePatientSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setSearchingPatient(true);
    try {
      const results = await api.searchPatients(searchQuery.trim());
      setSearchResults(results);
    } catch (err) {
      console.error(err);
    } finally {
      setSearchingPatient(false);
    }
  };

  // Pre-fill existing patient details to avoid duplicate records
  const handleSelectExistingPatient = (patient: Patient) => {
    setSelectedExistingPatient(patient);
    setFullName(patient.fullName);
    setAge(patient.age);
    setGender(patient.gender);
    setMobileNumber(patient.mobileNumber);
    setAddress(patient.address);
    if (patient.bloodGroup) setBloodGroup(patient.bloodGroup);
    setSearchResults([]);
    setSearchQuery('');
    setActionSuccess(`Existing record loaded for ${patient.fullName} (${patient.id}).`);
    setTimeout(() => setActionSuccess(null), 4000);
  };

  const handleClearPatientForm = () => {
    setSelectedExistingPatient(null);
    setFullName('');
    setAge('');
    setGender('Male');
    setMobileNumber('');
    setAddress('');
    setBloodGroup('');
    setSymptomsNotes('');
    setErrorMessage(null);
  };

  const handleWalkInSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!fullName.trim() || !age || !mobileNumber.trim() || !address.trim()) {
      setErrorMessage('Please fill in all mandatory patient fields.');
      return;
    }
    if (!selectedDeptId || !selectedDoctorId) {
      setErrorMessage('Please assign a department and doctor.');
      return;
    }

    setSubmitting(true);
    try {
      const today = new Date().toISOString().split('T')[0];
      const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      const res = await api.registerWalkIn({
        fullName: fullName.trim(),
        age: Number(age),
        gender,
        mobileNumber: mobileNumber.trim(),
        address: address.trim(),
        bloodGroup: bloodGroup || undefined,
        departmentId: selectedDeptId,
        doctorId: selectedDoctorId,
        appointmentDate: today,
        appointmentTime: `Walk-in (${nowTime})`,
        symptomsNotes: symptomsNotes.trim() || 'Counter Walk-in Patient',
        initialStatus: 'Waiting',
      });

      // Clear form
      handleClearPatientForm();
      fetchQueue();

      // Immediately launch printable OP Slip modal for the receptionist
      onPrintSlip(res.registration);
      setActionSuccess(
        `OP Slip ${res.registration.opNumber} generated! Token #${res.registration.tokenNumber} allocated for ${res.registration.doctorName}.`
      );
      setTimeout(() => setActionSuccess(null), 6000);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to complete counter registration.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleStatusUpdate = async (id: string, newStatus: RegistrationStatus) => {
    try {
      await api.updateRegistrationStatus(id, newStatus);
      fetchQueue();
    } catch (err: any) {
      alert(`Error updating status: ${err.message}`);
    }
  };

  const selectedDoctor = doctors.find((d) => d.id === selectedDoctorId);

  // Filter queue
  const filteredQueue = registrations.filter((r) => {
    if (queueStatusFilter !== 'all' && r.status !== queueStatusFilter) return false;
    if (queueSearch) {
      const q = queueSearch.toLowerCase();
      return (
        r.opNumber.toLowerCase().includes(q) ||
        r.patientName.toLowerCase().includes(q) ||
        r.mobileNumber.includes(q) ||
        r.doctorName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Staff Counter Top Bar */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-sky-600/30 border border-sky-500/40 flex items-center justify-center text-sky-400">
            <UserCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase font-semibold tracking-wider text-sky-400">
                Staff Counter Station
              </span>
              <span className="text-[11px] bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-2 py-0.5 rounded font-mono">
                {currentUser.role.toUpperCase()}
              </span>
            </div>
            <h2 className="text-lg md:text-xl font-bold tracking-tight text-white mt-0.5">
              {currentUser.name}
            </h2>
            <p className="text-xs text-slate-400">
              {currentUser.departmentAssigned || 'Outpatient Registration Desk 1'} · Authenticated Session
            </p>
          </div>
        </div>

        {/* Counter Tab Switcher */}
        <div className="flex items-center gap-2 w-full md:w-auto">
          <div className="flex items-center p-1 bg-slate-800 rounded-xl border border-slate-700/80 w-full sm:w-auto">
            <button
              onClick={() => setActiveTab('walkin')}
              className={`flex-1 sm:flex-none px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                activeTab === 'walkin'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Walk-in Registration Counter
            </button>
            <button
              onClick={() => setActiveTab('queue')}
              className={`flex-1 sm:flex-none px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                activeTab === 'queue'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Today's OP Queue ({registrations.length})
            </button>
          </div>

          <button
            onClick={onLogout}
            className="px-3 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-colors cursor-pointer shrink-0"
          >
            Sign Out
          </button>
        </div>
      </div>

      {actionSuccess && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-medium">{actionSuccess}</span>
        </div>
      )}

      {errorMessage && (
        <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span className="font-medium">{errorMessage}</span>
        </div>
      )}

      {/* TAB 1: WALK-IN REGISTRATION COUNTER */}
      {activeTab === 'walkin' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left 2 Cols: Walk-in Patient Form */}
          <div className="lg:col-span-2 space-y-6">
            {/* Duplicate Patient Search Card */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Search className="w-4 h-4 text-sky-600" />
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Search Existing Patient (Prevent Duplicate Records)
                  </h3>
                </div>
                {selectedExistingPatient && (
                  <button
                    type="button"
                    onClick={handleClearPatientForm}
                    className="text-xs text-rose-600 hover:underline cursor-pointer font-medium"
                  >
                    Clear & Register as New
                  </button>
                )}
              </div>

              <form onSubmit={handlePatientSearch} className="flex gap-2">
                <input
                  type="text"
                  placeholder="Enter patient mobile number (e.g. 9876543210) or full name..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="flex-1 px-3.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
                <button
                  type="submit"
                  disabled={searchingPatient}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer shrink-0"
                >
                  {searchingPatient ? 'Searching...' : 'Search Patient'}
                </button>
              </form>

              {/* Patient Search Results */}
              {searchResults.length > 0 && (
                <div className="mt-3 divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden bg-slate-50/70">
                  <div className="p-2 bg-slate-100 text-[11px] font-semibold text-slate-600">
                    Found {searchResults.length} existing patient record(s) in database:
                  </div>
                  {searchResults.map((p) => (
                    <div
                      key={p.id}
                      className="p-3 flex items-center justify-between hover:bg-white transition-colors"
                    >
                      <div>
                        <div className="font-bold text-xs text-slate-900">
                          {p.fullName}{' '}
                          <span className="font-mono text-slate-500 font-normal">({p.id})</span>
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {p.age} Yrs · {p.gender} · Mobile: {p.mobileNumber} · {p.address}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleSelectExistingPatient(p)}
                        className="px-3 py-1 bg-sky-700 hover:bg-sky-600 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer shrink-0"
                      >
                        Use This Patient
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {selectedExistingPatient && (
                <div className="mt-3 p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs text-emerald-900">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>
                      Reusing Existing Patient Profile:{' '}
                      <strong>
                        {selectedExistingPatient.fullName} ({selectedExistingPatient.id})
                      </strong>
                    </span>
                  </div>
                  <span className="font-mono text-[11px] text-emerald-700">Mobile: {selectedExistingPatient.mobileNumber}</span>
                </div>
              )}
            </div>

            {/* Main Walk-in Registration Form */}
            <form
              onSubmit={handleWalkInSubmit}
              className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-base font-bold text-slate-900">Walk-in Patient Details</h3>
                  <p className="text-xs text-slate-500">
                    Immediate OP slip printing and automatic queue arrival
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[11px] bg-sky-50 text-sky-800 border border-sky-200 px-2 py-1 rounded font-semibold">
                    Payment: Paid at Counter ($400 - $500)
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Patient Full Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Maria Gonzalez"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Age (Years) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="125"
                    required
                    placeholder="e.g. 42"
                    value={age}
                    onChange={(e) => setAge(e.target.value ? parseInt(e.target.value, 10) : '')}
                    className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Gender <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as Gender)}
                    className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Mobile Number <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="e.g. 9811223344"
                    value={mobileNumber}
                    onChange={(e) => setMobileNumber(e.target.value)}
                    className="w-full px-3.5 py-2 text-sm font-mono bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Blood Group (Optional)
                  </label>
                  <select
                    value={bloodGroup}
                    onChange={(e) => setBloodGroup(e.target.value)}
                    className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                  >
                    <option value="">Unknown / None</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                  </select>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Address <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Locality, City, PIN code"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                </div>
              </div>

              {/* Department & Doctor */}
              <div className="pt-3 border-t border-slate-100">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Department <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={selectedDeptId}
                      onChange={(e) => setSelectedDeptId(e.target.value)}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500 font-medium"
                    >
                      {departments.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.name} ({d.floor})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Consulting Doctor <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={selectedDoctorId}
                      onChange={(e) => setSelectedDoctorId(e.target.value)}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500 font-medium"
                    >
                      {doctors.map((doc) => (
                        <option key={doc.id} value={doc.id}>
                          {doc.name} - {doc.roomNumber} (${doc.consultationFee})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Brief Complaint / Symptoms Notes (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Acute joint pain, fever review, or BP check"
                  value={symptomsNotes}
                  onChange={(e) => setSymptomsNotes(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={handleClearPatientForm}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
                >
                  Reset Form
                </button>

                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex items-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-sm transition-colors cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>{submitting ? 'Allocating Token...' : 'Generate OP & Print Slip Immediately'}</span>
                </button>
              </div>
            </form>
          </div>

          {/* Right Column: Counter Helper & Active Doctor Status */}
          <div className="space-y-4">
            {/* Selected Doctor Summary Card */}
            {selectedDoctor && (
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
                <div className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center justify-between">
                  <span>Assigned Doctor Info</span>
                  <span className="text-[11px] text-emerald-700 font-bold">OPD Active</span>
                </div>
                <div className="p-3 bg-sky-50 rounded-xl border border-sky-100">
                  <div className="font-bold text-sm text-sky-950">{selectedDoctor.name}</div>
                  <div className="text-xs text-sky-800 font-medium">{selectedDoctor.qualification}</div>
                  <div className="text-[11px] text-slate-600 mt-1">{selectedDoctor.specialization}</div>
                  <div className="mt-2 pt-2 border-t border-sky-200/60 flex items-center justify-between text-xs font-semibold">
                    <span className="text-slate-700">{selectedDoctor.roomNumber}</span>
                    <span className="text-slate-900 font-bold">${selectedDoctor.consultationFee}</span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">
                    Floor: {selectedDoctor.floor}
                  </div>
                </div>
              </div>
            )}

            {/* Receptionist Quick Guide */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs text-xs space-y-3">
              <h4 className="font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-sky-600" />
                <span>Counter Guidelines</span>
              </h4>
              <ul className="text-slate-600 space-y-2 leading-relaxed">
                <li className="flex items-start gap-1.5">
                  <span className="text-sky-600 font-bold">•</span>
                  <span>
                    <strong>Duplicate Check:</strong> Always search mobile number first. If the patient has visited before, their details auto-populate.
                  </span>
                </li>
                <li className="flex items-start gap-1.5">
                  <span className="text-sky-600 font-bold">•</span>
                  <span>
                    <strong>Instant Printing:</strong> After submission, hand the physical OP slip to the patient. Tell them to proceed to the assigned room.
                  </span>
                </li>
                <li className="flex items-start gap-1.5">
                  <span className="text-sky-600 font-bold">•</span>
                  <span>
                    <strong>Queue Management:</strong> Walk-in patients automatically enter the 'Waiting' queue for doctor calling.
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: TODAY'S OP QUEUE & ARRIVAL MANAGER */}
      {activeTab === 'queue' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-slate-900">Today's Live Outpatient Queue</h3>
              <p className="text-xs text-slate-500">
                Track patient arrival, update waiting status, and call into consultation rooms
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={fetchQueue}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingQueue ? 'animate-spin' : ''}`} />
                <span>Refresh</span>
              </button>
            </div>
          </div>

          {/* Queue Filter Controls */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 pt-1">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search patient name, OP number, doctor, or mobile..."
                value={queueSearch}
                onChange={(e) => setQueueSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>

            {/* Status Filter */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl border border-slate-200">
              {['all', 'Registered', 'Waiting', 'In Consultation', 'Completed'].map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setQueueStatusFilter(st)}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                    queueStatusFilter === st
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {st === 'all' ? 'All Status' : st}
                </button>
              ))}
            </div>
          </div>

          {/* Queue Table */}
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100/80 text-slate-700 uppercase font-bold text-[10px] tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">Token & OP No.</th>
                  <th className="px-4 py-3">Patient Details</th>
                  <th className="px-4 py-3">Department & Doctor</th>
                  <th className="px-4 py-3">Type & Slot</th>
                  <th className="px-4 py-3">Current Status</th>
                  <th className="px-4 py-3 text-right">Counter Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {filteredQueue.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-slate-500">
                      No outpatient records found matching filter.
                    </td>
                  </tr>
                ) : (
                  filteredQueue.map((reg) => (
                    <tr key={reg.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-4 py-3.5">
                        <div className="font-mono text-base font-extrabold text-sky-900">
                          #{reg.tokenNumber}
                        </div>
                        <div className="font-mono text-[11px] text-slate-500 font-semibold">
                          {reg.opNumber}
                        </div>
                      </td>

                      <td className="px-4 py-3.5">
                        <div className="font-bold text-slate-900">{reg.patientName}</div>
                        <div className="text-[11px] text-slate-500">
                          {reg.age}Y · {reg.gender} · {reg.mobileNumber}
                        </div>
                      </td>

                      <td className="px-4 py-3.5">
                        <div className="font-semibold text-slate-800">{reg.doctorName}</div>
                        <div className="text-[11px] text-sky-800">
                          {reg.departmentName} ({reg.roomNumber})
                        </div>
                      </td>

                      <td className="px-4 py-3.5">
                        <span className="font-medium capitalize text-slate-700 block">
                          {reg.registrationType}
                        </span>
                        <span className="text-[11px] text-slate-500 font-mono">
                          {reg.appointmentTime}
                        </span>
                      </td>

                      <td className="px-4 py-3.5">
                        <span
                          className={`inline-block px-2.5 py-1 text-[11px] font-bold rounded-md border ${
                            reg.status === 'Waiting'
                              ? 'bg-amber-50 text-amber-800 border-amber-300'
                              : reg.status === 'In Consultation'
                              ? 'bg-sky-50 text-sky-800 border-sky-300 animate-pulse'
                              : reg.status === 'Completed'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                              : reg.status === 'Cancelled'
                              ? 'bg-rose-50 text-rose-800 border-rose-300'
                              : 'bg-slate-100 text-slate-700 border-slate-300'
                          }`}
                        >
                          {reg.status}
                        </span>
                      </td>

                      <td className="px-4 py-3.5 text-right space-x-1">
                        {reg.status === 'Registered' && (
                          <button
                            type="button"
                            onClick={() => handleStatusUpdate(reg.id, 'Waiting')}
                            className="px-2.5 py-1 text-[11px] font-semibold bg-amber-500 hover:bg-amber-600 text-white rounded-md transition-colors cursor-pointer"
                          >
                            Mark Arrived
                          </button>
                        )}

                        {reg.status === 'Waiting' && (
                          <button
                            type="button"
                            onClick={() => handleStatusUpdate(reg.id, 'In Consultation')}
                            className="px-2.5 py-1 text-[11px] font-semibold bg-sky-700 hover:bg-sky-600 text-white rounded-md transition-colors cursor-pointer"
                          >
                            Call into Room
                          </button>
                        )}

                        {reg.status === 'In Consultation' && (
                          <button
                            type="button"
                            onClick={() => handleStatusUpdate(reg.id, 'Completed')}
                            className="px-2.5 py-1 text-[11px] font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-md transition-colors cursor-pointer"
                          >
                            Complete
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => onPrintSlip(reg)}
                          className="px-2 py-1 text-[11px] font-medium text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-md transition-colors cursor-pointer inline-flex items-center gap-1"
                          title="Print or view slip"
                        >
                          <Printer className="w-3 h-3" />
                          <span>Slip</span>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
