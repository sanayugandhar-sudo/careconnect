import React from 'react';
import {
  CalendarCheck2,
  Clock,
  ShieldCheck,
  Stethoscope,
  Building2,
  ArrowDown,
  Sparkles,
  Phone,
  Search,
} from 'lucide-react';
import { HospitalInfo } from '../types/index';

interface HospitalHeroProps {
  hospitalInfo: HospitalInfo | null;
  onStartBooking: () => void;
  onOpenLookup: () => void;
  onOpenAi: () => void;
}

export const HospitalHero: React.FC<HospitalHeroProps> = ({
  hospitalInfo,
  onStartBooking,
  onOpenLookup,
  onOpenAi,
}) => {
  return (
    <div className="relative rounded-3xl overflow-hidden bg-slate-900 text-white shadow-xl border border-slate-800">
      {/* Background Image with Measured Contrast Scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/hospital_exterior_careconnect_1794246852925.jpg"
          alt="CareConnect Hospital Campus Exterior"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-30 mix-blend-luminosity scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/90 to-sky-950/80" />
      </div>

      {/* Content */}
      <div className="relative z-10 p-6 md:p-10 lg:p-12 max-w-4xl space-y-6">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-sky-500/10 text-sky-300 border border-sky-400/20 rounded-full text-xs font-semibold backdrop-blur-xs">
          <Building2 className="w-3.5 h-3.5 text-sky-400" />
          <span>Outpatient Department (OPD) Centralized Registration</span>
        </div>

        <div className="space-y-3">
          <h1 className="text-2xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-white leading-tight">
            Streamlined Outpatient Care & Instant OP Slips
          </h1>
          <p className="text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed">
            Register for hospital consultations from the comfort of your home or at the physical reception desk. Get guaranteed sequential tokens, AI department routing assistance, and downloadable medical slips.
          </p>
        </div>

        {/* Feature Badges Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs pt-1 max-w-2xl">
          <div className="p-3 bg-white/5 border border-white/10 rounded-xl backdrop-blur-xs space-y-1">
            <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
              <CalendarCheck2 className="w-4 h-4" />
              <span>Instant Tokens</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Unique OP sequence and guaranteed time slot
            </p>
          </div>

          <div className="p-3 bg-white/5 border border-white/10 rounded-xl backdrop-blur-xs space-y-1">
            <div className="flex items-center gap-1.5 text-sky-400 font-semibold">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>AI Triage Guide</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Department matching based on described symptoms
            </p>
          </div>

          <div className="p-3 bg-white/5 border border-white/10 rounded-xl backdrop-blur-xs space-y-1 col-span-2 sm:col-span-1">
            <div className="flex items-center gap-1.5 text-teal-400 font-semibold">
              <ShieldCheck className="w-4 h-4" />
              <span>Counter & Online</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Synchronized records to prevent duplicate files
            </p>
          </div>
        </div>

        {/* Call to action buttons */}
        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            type="button"
            onClick={onStartBooking}
            className="px-6 py-3 bg-sky-600 hover:bg-sky-500 text-white text-xs sm:text-sm font-bold rounded-xl shadow-md transition-all cursor-pointer inline-flex items-center gap-2"
          >
            <span>Register & Generate OP Slip</span>
            <ArrowDown className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={onOpenLookup}
            className="px-4 py-3 bg-slate-800/80 hover:bg-slate-700/90 text-slate-200 text-xs sm:text-sm font-semibold rounded-xl border border-slate-700 transition-colors cursor-pointer inline-flex items-center gap-2"
          >
            <Search className="w-4 h-4 text-slate-400" />
            <span>Check My OP Slip</span>
          </button>

          <button
            type="button"
            onClick={onOpenAi}
            className="px-4 py-3 bg-teal-900/40 hover:bg-teal-900/60 text-teal-200 text-xs sm:text-sm font-semibold rounded-xl border border-teal-700/50 transition-colors cursor-pointer inline-flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>AI Symptom Guide</span>
          </button>
        </div>
      </div>
    </div>
  );
};
