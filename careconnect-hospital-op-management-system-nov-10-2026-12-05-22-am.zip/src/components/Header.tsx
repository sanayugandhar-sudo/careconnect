import React from 'react';
import {
  Phone,
  Building2,
  Lock,
  UserCheck,
  Search,
  Activity,
  LogOut,
  Calendar,
} from 'lucide-react';
import { HospitalInfo, StaffUser } from '../types/index';

interface HeaderProps {
  hospitalInfo: HospitalInfo | null;
  activeView: 'patient' | 'reception' | 'admin' | 'queue';
  setActiveView: (view: 'patient' | 'reception' | 'admin' | 'queue') => void;
  currentUser: StaffUser | null;
  onOpenAuth: () => void;
  onOpenLookup: () => void;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  hospitalInfo,
  activeView,
  setActiveView,
  currentUser,
  onOpenAuth,
  onOpenLookup,
  onLogout,
}) => {
  return (
    <header className="no-print bg-white border-b border-slate-200 sticky top-0 z-40">
      {/* Quiet Hospital Emergency & Helpline Ribbon */}
      <div className="bg-slate-900 text-slate-300 text-[11px] px-4 md:px-8 py-1.5 flex flex-wrap items-center justify-between gap-2 border-b border-slate-800">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span className="font-semibold text-slate-200">
              {hospitalInfo?.name || 'CareConnect Multispeciality Hospital'}
            </span>
            <span className="text-slate-500 hidden sm:inline">· Outpatient (OPD) Services</span>
          </div>
          <div className="hidden lg:flex items-center gap-1 text-slate-400">
            <span>OPD Hours: {hospitalInfo?.opdHours || 'Mon-Sat 8:30 AM - 8:00 PM'}</span>
          </div>
        </div>

        <div className="flex items-center gap-3 ml-auto text-xs">
          <span className="text-rose-400 font-semibold flex items-center gap-1">
            <Phone className="w-3 h-3" />
            <span>Emergency 24x7: 108</span>
          </span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-300 font-mono">
            Helpline: {hospitalInfo?.helpline || '+1 (800) 555-CARE'}
          </span>
        </div>
      </div>

      {/* 3-Zone Top Bar Contract */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-3.5 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <div
          onClick={() => setActiveView('patient')}
          className="flex items-center gap-2.5 cursor-pointer whitespace-nowrap shrink-0 group"
        >
          <div className="w-9 h-9 rounded-lg bg-sky-700 text-white flex items-center justify-center font-bold text-lg shadow-sm group-hover:bg-sky-600 transition-colors">
            C+
          </div>
          <span className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap">
            CareConnect <span className="text-sky-700 font-normal">OPD</span>
          </span>
        </div>

        {/* Zone 2: Clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-600">
          <button
            onClick={() => setActiveView('patient')}
            className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeView === 'patient'
                ? 'text-sky-700 font-bold border-b-2 border-sky-700 pb-0.5'
                : 'hover:text-slate-900'
            }`}
          >
            Book OP Online
          </button>

          <button
            onClick={onOpenLookup}
            className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Check OP Status
          </button>

          <button
            onClick={() => setActiveView('queue')}
            className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeView === 'queue'
                ? 'text-sky-700 font-bold border-b-2 border-sky-700 pb-0.5'
                : 'hover:text-slate-900'
            }`}
          >
            Live OPD Queue
          </button>

          <button
            onClick={() => {
              if (currentUser && (currentUser.role === 'receptionist' || currentUser.role === 'admin')) {
                setActiveView('reception');
              } else {
                setActiveView('reception');
              }
            }}
            className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeView === 'reception'
                ? 'text-sky-700 font-bold border-b-2 border-sky-700 pb-0.5'
                : 'hover:text-slate-900'
            }`}
          >
            Reception Counter
          </button>

          <button
            onClick={() => {
              setActiveView('admin');
            }}
            className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeView === 'admin'
                ? 'text-sky-700 font-bold border-b-2 border-sky-700 pb-0.5'
                : 'hover:text-slate-900'
            }`}
          >
            Admin Dashboard
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-2.5 shrink-0">
          {currentUser ? (
            <div className="flex items-center gap-2">
              <span className="hidden sm:inline-block text-xs font-medium text-slate-700 truncate max-w-[140px]">
                {currentUser.name} ({currentUser.role})
              </span>
              <button
                onClick={onLogout}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg transition-colors cursor-pointer inline-flex items-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer inline-flex items-center gap-1.5 shadow-2xs"
            >
              <Lock className="w-3 h-3 text-sky-400" />
              <span>Staff Login</span>
            </button>
          )}
        </div>
      </div>

      {/* Mobile Nav Sub-strip */}
      <div className="md:hidden flex items-center justify-around py-2 px-2 bg-slate-50 border-t border-slate-200 text-[11px] font-semibold text-slate-600 overflow-x-auto">
        <button
          onClick={() => setActiveView('patient')}
          className={`px-2 py-1 rounded cursor-pointer whitespace-nowrap ${
            activeView === 'patient' ? 'bg-sky-100 text-sky-900 font-bold' : ''
          }`}
        >
          Book OP
        </button>
        <button onClick={onOpenLookup} className="px-2 py-1 rounded cursor-pointer whitespace-nowrap">
          Check Slip
        </button>
        <button
          onClick={() => setActiveView('queue')}
          className={`px-2 py-1 rounded cursor-pointer whitespace-nowrap ${
            activeView === 'queue' ? 'bg-sky-100 text-sky-900 font-bold' : ''
          }`}
        >
          Live Board
        </button>
        <button
          onClick={() => setActiveView('reception')}
          className={`px-2 py-1 rounded cursor-pointer whitespace-nowrap ${
            activeView === 'reception' ? 'bg-sky-100 text-sky-900 font-bold' : ''
          }`}
        >
          Counter
        </button>
        <button
          onClick={() => setActiveView('admin')}
          className={`px-2 py-1 rounded cursor-pointer whitespace-nowrap ${
            activeView === 'admin' ? 'bg-sky-100 text-sky-900 font-bold' : ''
          }`}
        >
          Admin
        </button>
      </div>
    </header>
  );
};
