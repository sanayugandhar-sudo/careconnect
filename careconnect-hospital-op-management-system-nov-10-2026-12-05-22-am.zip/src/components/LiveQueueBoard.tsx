import React, { useState, useEffect } from 'react';
import { Monitor, RefreshCw, Clock, Building2, Stethoscope, AlertCircle, Search, Filter } from 'lucide-react';
import { api } from '../api';

export const LiveQueueBoard: React.FC = () => {
  const [queue, setQueue] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [lastRefreshed, setLastRefreshed] = useState<Date>(new Date());
  const [selectedDept, setSelectedDept] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const fetchLive = async () => {
    setLoading(true);
    try {
      const data = await api.getLiveQueue();
      setQueue(data);
      setLastRefreshed(new Date());
    } catch (err) {
      console.error('Failed to fetch live queue', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLive();
    const interval = setInterval(fetchLive, 10000);
    return () => clearInterval(interval);
  }, []);

  // Unique departments in today's queue
  const departmentsInQueue = Array.from(new Set(queue.map((q) => q.departmentName))).filter(Boolean);

  const filteredQueue = queue.filter((item) => {
    if (selectedDept !== 'all' && item.departmentName !== selectedDept) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        item.opNumber.toLowerCase().includes(q) ||
        item.doctorName.toLowerCase().includes(q) ||
        item.roomNumber.toLowerCase().includes(q) ||
        String(item.tokenNumber).includes(q)
      );
    }
    return true;
  });

  const currentlyCalling = filteredQueue.filter((q) => q.status === 'In Consultation');
  const waitingList = filteredQueue.filter((q) => q.status === 'Waiting');

  return (
    <div className="space-y-6">
      {/* Board Header */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border border-slate-800">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 bg-emerald-500/20 text-emerald-400 border border-emerald-400/30 rounded-xl flex items-center justify-center">
            <Monitor className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase font-semibold text-emerald-400 tracking-wider">
                Public OPD Waiting Hall Monitor
              </span>
              <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-300 border border-slate-700">
                Live Feed (Auto-Refreshes)
              </span>
            </div>
            <h2 className="text-xl md:text-2xl font-bold tracking-tight text-white mt-0.5">
              Current OPD Token Calling Display
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-3 text-xs text-slate-400">
          <span>
            Updated:{' '}
            <strong className="text-white font-mono">
              {lastRefreshed.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </strong>
          </span>
          <button
            onClick={fetchLive}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition-colors cursor-pointer inline-flex items-center gap-1.5"
            title="Refresh Display"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span className="text-xs font-medium">Refresh</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Department Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          <span className="text-xs font-bold text-slate-500 uppercase mr-1 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" />
            <span>Clinic:</span>
          </span>
          <button
            type="button"
            onClick={() => setSelectedDept('all')}
            className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
              selectedDept === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            All Specialty Clinics ({queue.length})
          </button>
          {departmentsInQueue.map((dept) => (
            <button
              key={dept}
              type="button"
              onClick={() => setSelectedDept(dept)}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                selectedDept === dept
                  ? 'bg-sky-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {dept}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search token or doctor..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-none focus:ring-1 focus:ring-sky-500"
          />
        </div>
      </div>

      {/* Hallway Display: NOW CONSULTING (Big Prominent Numbers) */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
            <span>Now Calling Inside OPD Rooms</span>
          </h3>
          <span className="text-xs text-slate-500">
            Please proceed immediately to the doctor's room when your token is called
          </span>
        </div>

        {currentlyCalling.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-2xl border border-slate-200 text-xs text-slate-500">
            No patient currently in consultation room for this filter. Next token will be called shortly.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {currentlyCalling.map((item, idx) => (
              <div
                key={idx}
                className="bg-white p-5 rounded-2xl border-2 border-emerald-500 shadow-md space-y-3 relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 bg-emerald-600 text-white text-[10px] uppercase font-black px-3 py-1 rounded-bl-lg tracking-wider">
                  IN CONSULTATION
                </div>

                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-xl bg-emerald-50 border border-emerald-200 flex flex-col items-center justify-center text-emerald-800 shrink-0">
                    <span className="text-[10px] uppercase font-bold text-emerald-600 leading-none">
                      Token
                    </span>
                    <span className="font-mono text-2xl font-black mt-0.5">#{item.tokenNumber}</span>
                  </div>

                  <div>
                    <div className="text-xs font-mono font-bold text-slate-500">{item.opNumber}</div>
                    <div className="text-sm font-bold text-slate-900">{item.patientInitials}</div>
                    <div className="text-xs font-semibold text-emerald-800 mt-0.5">
                      {item.roomNumber}
                    </div>
                  </div>
                </div>

                <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
                  <span className="font-medium">{item.doctorName}</span>
                  <span className="text-[11px] text-slate-500">{item.departmentName}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Hallway Display: NEXT WAITING TOKENS */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              Patients Waiting in OPD Lobby ({waitingList.length})
            </h3>
            <p className="text-[11px] text-slate-500">
              Tokens in queue ordered by arrival time
            </p>
          </div>
          <Clock className="w-4 h-4 text-amber-600" />
        </div>

        {waitingList.length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-500">
            No waiting patients in queue for this selection.
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {waitingList.map((item, idx) => (
              <div
                key={idx}
                className="p-3 bg-amber-50/60 border border-amber-200/80 rounded-xl text-center space-y-1"
              >
                <div className="text-[10px] uppercase font-semibold text-amber-800">Next In Line</div>
                <div className="font-mono text-2xl font-black text-amber-950">
                  #{item.tokenNumber}
                </div>
                <div className="text-[11px] font-mono font-bold text-slate-600 truncate">
                  {item.opNumber}
                </div>
                <div className="text-[11px] font-medium text-slate-800 truncate">
                  {item.roomNumber}
                </div>
                <div className="text-[10px] text-slate-500 truncate">{item.doctorName}</div>
              </div>
            ))}
          </div>
        )}

        <div className="pt-3 border-t border-slate-100 text-[11px] text-slate-500 flex items-center gap-1.5">
          <AlertCircle className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span>
            Display complies with patient privacy protocols. Personal phone numbers and addresses are protected and not displayed on public boards.
          </span>
        </div>
      </div>
    </div>
  );
};
