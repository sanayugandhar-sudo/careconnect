import React from 'react';
import { AlertTriangle, UserCheck, Shield, Sparkles, Building2 } from 'lucide-react';
import { StaffUser } from '../types/index';

interface DemoNoticeBannerProps {
  currentUser: StaffUser | null;
  onQuickSwitchRole: (role: 'patient' | 'receptionist' | 'admin') => void;
}

export const DemoNoticeBanner: React.FC<DemoNoticeBannerProps> = ({
  currentUser,
  onQuickSwitchRole,
}) => {
  return (
    <div className="no-print bg-amber-50/90 border-b border-amber-200/80 px-4 md:px-8 py-2 text-xs text-amber-900">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
          <span className="font-semibold">DEMONSTRATION SYSTEM:</span>
          <span className="text-amber-800 text-[11px]">
            CareConnect is an outpatient management prototype. Patient records are simulated demo data. Do not use for real clinical emergencies.
          </span>
        </div>

        {/* Quick Role Switcher Chips for Evaluators */}
        <div className="flex items-center gap-1.5 flex-wrap shrink-0">
          <span className="text-[10px] uppercase font-bold text-amber-800 tracking-wider">
            Quick Test:
          </span>
          <button
            type="button"
            onClick={() => onQuickSwitchRole('patient')}
            className={`px-2 py-0.5 rounded text-[11px] font-semibold transition-colors cursor-pointer border ${
              !currentUser
                ? 'bg-amber-200 border-amber-400 text-amber-950 font-bold'
                : 'bg-white/80 hover:bg-white text-slate-700 border-amber-300'
            }`}
          >
            Patient View
          </button>
          <button
            type="button"
            onClick={() => onQuickSwitchRole('receptionist')}
            className={`px-2 py-0.5 rounded text-[11px] font-semibold transition-colors cursor-pointer border ${
              currentUser?.role === 'receptionist'
                ? 'bg-sky-200 border-sky-400 text-sky-950 font-bold'
                : 'bg-white/80 hover:bg-white text-slate-700 border-amber-300'
            }`}
          >
            Receptionist Counter
          </button>
          <button
            type="button"
            onClick={() => onQuickSwitchRole('admin')}
            className={`px-2 py-0.5 rounded text-[11px] font-semibold transition-colors cursor-pointer border ${
              currentUser?.role === 'admin'
                ? 'bg-emerald-200 border-emerald-400 text-emerald-950 font-bold'
                : 'bg-white/80 hover:bg-white text-slate-700 border-amber-300'
            }`}
          >
            Admin Dashboard
          </button>
        </div>
      </div>
    </div>
  );
};
