import React, { useRef } from 'react';
import {
  Printer,
  Download,
  X,
  Building2,
  Calendar,
  Clock,
  User,
  Phone,
  MapPin,
  CheckCircle2,
  FileText,
  AlertCircle,
} from 'lucide-react';
import { OPRegistration, HospitalInfo } from '../types/index';

interface OPSlipModalProps {
  registration: OPRegistration | null;
  hospitalInfo: HospitalInfo | null;
  onClose: () => void;
}

export const OPSlipModal: React.FC<OPSlipModalProps> = ({
  registration,
  hospitalInfo,
  onClose,
}) => {
  const slipRef = useRef<HTMLDivElement>(null);

  if (!registration) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    // Generate self-contained, printable medical OP slip HTML document
    const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>CareConnect OP Slip - ${registration.opNumber}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #f8fafc; color: #1e293b; padding: 24px; margin: 0; }
    .slip { max-width: 650px; margin: 0 auto; background: #ffffff; border: 1px solid #cbd5e1; border-radius: 8px; padding: 28px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
    .header { border-bottom: 2px solid #0f172a; padding-bottom: 16px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: flex-start; }
    .hospital-title { font-size: 20px; font-weight: bold; color: #0f172a; margin: 0; }
    .tagline { font-size: 12px; color: #64748b; margin-top: 2px; }
    .token-strip { background: #f1f5f9; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px 16px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
    .token-num { font-size: 28px; font-weight: 900; color: #047857; font-family: monospace; }
    .op-num { font-size: 18px; font-weight: bold; color: #0369a1; font-family: monospace; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; border-bottom: 1px solid #e2e8f0; padding-bottom: 16px; margin-bottom: 16px; }
    .label { font-size: 11px; text-transform: uppercase; color: #64748b; font-weight: bold; }
    .value { font-size: 13px; font-weight: 600; color: #0f172a; margin-top: 2px; }
    .barcode { font-family: monospace; font-size: 12px; letter-spacing: 3px; text-align: center; margin-top: 10px; }
    .footer { font-size: 10px; color: #64748b; text-align: center; border-top: 1px dashed #cbd5e1; padding-top: 12px; margin-top: 16px; }
    @media print { body { padding: 0; background: white; } .slip { box-shadow: none; border: 1px solid #94a3b8; } }
  </style>
</head>
<body>
  <div class="slip">
    <div class="header">
      <div>
        <h1 class="hospital-title">${hospitalInfo?.name || 'CareConnect Multispeciality Hospital'}</h1>
        <div class="tagline">${hospitalInfo?.tagline || 'Center for Clinical Excellence & Outpatient Care'}</div>
        <div style="font-size: 11px; color: #64748b; margin-top: 4px;">${hospitalInfo?.address}, ${hospitalInfo?.cityStateZip}</div>
      </div>
      <div style="text-align: right; font-size: 11px;">
        <div style="font-weight: bold; color: #0369a1;">OUTPATIENT OP SLIP</div>
        <div>Ph: ${hospitalInfo?.helpline || '+1 (800) 555-CARE'}</div>
        <div style="color: #e11d48; font-weight: bold;">Emergency: 108</div>
      </div>
    </div>

    <div class="token-strip">
      <div>
        <div class="label">OP Registration No.</div>
        <div class="op-num">${registration.opNumber}</div>
        <div style="font-size: 10px; color: #64748b;">Patient ID: ${registration.patientId}</div>
      </div>
      <div style="text-align: center;">
        <div class="label">Token Number</div>
        <div class="token-num">#${registration.tokenNumber}</div>
        <div style="font-size: 11px; font-weight: 600; color: #0f172a;">${registration.status}</div>
      </div>
      <div style="text-align: right;">
        <div class="label">Scheduled Slot</div>
        <div class="value">${registration.appointmentDate}</div>
        <div style="color: #0369a1; font-weight: bold; font-size: 12px;">${registration.appointmentTime}</div>
      </div>
    </div>

    <div class="grid">
      <div>
        <div style="font-weight: bold; font-size: 12px; margin-bottom: 8px; color: #0f172a;">PATIENT INFORMATION</div>
        <div style="margin-bottom: 6px;"><span class="label">Name:</span> <span class="value">${registration.patientName}</span></div>
        <div style="margin-bottom: 6px;"><span class="label">Age / Gender:</span> <span class="value">${registration.age} Yrs · ${registration.gender}</span></div>
        <div style="margin-bottom: 6px;"><span class="label">Mobile:</span> <span class="value">${registration.mobileNumber}</span></div>
        <div><span class="label">Address:</span> <span class="value">${registration.address}</span></div>
      </div>
      <div>
        <div style="font-weight: bold; font-size: 12px; margin-bottom: 8px; color: #0f172a;">CLINICAL ASSIGNMENT</div>
        <div style="margin-bottom: 6px;"><span class="label">Department:</span> <span class="value">${registration.departmentName}</span></div>
        <div style="margin-bottom: 6px;"><span class="label">Doctor:</span> <span class="value">${registration.doctorName}</span></div>
        <div style="margin-bottom: 6px;"><span class="label">Room / Floor:</span> <span class="value">${registration.roomNumber} (${registration.floor})</span></div>
        <div><span class="label">Consultation Fee:</span> <span class="value">$${registration.consultationFee} (${registration.paymentStatus})</span></div>
      </div>
    </div>

    <div style="display: flex; justify-content: space-between; align-items: center; font-size: 11px; color: #64748b;">
      <div>Registered on: <strong>${new Date(registration.registrationDate).toLocaleString()}</strong> (${registration.registrationType})</div>
      <div class="barcode">||| | |||| | || |||| | ||| | |||</div>
    </div>

    <div class="footer">
      DEMO SYSTEM: CareConnect Outpatient Management Simulation. Present this slip at the nursing counter 15 minutes before your time. Valid for 7 days.
    </div>
  </div>
</body>
</html>`;
    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `OP_Slip_${registration.opNumber}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative w-full max-w-2xl bg-white rounded-xl shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Top Modal Controls (Hidden in Print) */}
        <div className="no-print flex items-center justify-between px-6 py-3.5 bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span className="font-semibold text-sm">OP Registration Slip Ready</span>
            <span className="text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-2 py-0.5 rounded">
              {registration.registrationType === 'online' ? 'Online E-Pass' : 'Counter Walk-in'}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white text-xs font-medium rounded-lg transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Slip</span>
            </button>
            <button
              onClick={handleDownload}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer ml-1"
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Slip Container */}
        <div
          id="op-slip-printable"
          ref={slipRef}
          className="p-6 md:p-8 bg-white text-slate-800 text-sm font-sans"
        >
          {/* Hospital Header Banner */}
          <div className="border-b-2 border-slate-800 pb-4 mb-5">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-sky-700 text-white rounded-lg flex items-center justify-center font-bold text-2xl shadow-sm">
                  C+
                </div>
                <div>
                  <h2 className="text-xl font-bold tracking-tight text-slate-900 leading-tight">
                    {hospitalInfo?.name || 'CareConnect Multispeciality Hospital'}
                  </h2>
                  <p className="text-xs text-slate-600 font-medium">
                    {hospitalInfo?.tagline || 'Center for Clinical Excellence & Outpatient Care'}
                  </p>
                  <p className="text-[11px] text-slate-500">
                    {hospitalInfo?.address}, {hospitalInfo?.cityStateZip}
                  </p>
                </div>
              </div>
              <div className="text-right shrink-0">
                <div className="text-[11px] font-semibold text-sky-800 uppercase tracking-wider">
                  Outpatient Registration Slip
                </div>
                <div className="text-[10px] text-slate-500">
                  Ph: {hospitalInfo?.helpline || '040-6789-4000'}
                </div>
                <div className="text-[10px] text-rose-600 font-semibold">
                  {hospitalInfo?.emergency || 'Emergency 24x7: 108'}
                </div>
              </div>
            </div>
          </div>

          {/* Prominent OP Number & Token Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-3.5 bg-slate-50 border border-slate-200 rounded-lg mb-5">
            <div>
              <div className="text-[10px] uppercase font-semibold text-slate-500 tracking-wider">
                OP Registration No.
              </div>
              <div className="font-mono text-lg font-bold text-sky-900 tracking-tight">
                {registration.opNumber}
              </div>
              <div className="text-[10px] text-slate-500">
                Reg ID: {registration.id.slice(0, 14)}
              </div>
            </div>

            <div className="text-center sm:text-left">
              <div className="text-[10px] uppercase font-semibold text-slate-500 tracking-wider">
                OPD Token No.
              </div>
              <div className="font-mono text-2xl font-black text-emerald-700 leading-none my-0.5">
                #{registration.tokenNumber}
              </div>
              <div className="text-[10px] text-slate-600 font-medium">
                {registration.status}
              </div>
            </div>

            <div className="col-span-2 sm:col-span-1 text-right">
              <div className="text-[10px] uppercase font-semibold text-slate-500 tracking-wider">
                Appointment Schedule
              </div>
              <div className="font-bold text-slate-800 text-xs mt-0.5">
                {registration.appointmentDate}
              </div>
              <div className="font-semibold text-sky-700 text-xs">
                {registration.appointmentTime}
              </div>
            </div>
          </div>

          {/* 2-Column Grid: Patient Details & Doctor Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-4 border-b border-slate-200">
            {/* Patient Info Card */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 pb-1 border-b border-slate-100">
                <User className="w-3.5 h-3.5 text-sky-600" />
                <span>Patient Identification</span>
              </div>
              <div className="grid grid-cols-3 gap-y-1.5 text-xs">
                <span className="text-slate-500">Patient Name:</span>
                <span className="col-span-2 font-semibold text-slate-900">
                  {registration.patientName}
                </span>

                <span className="text-slate-500">Age / Gender:</span>
                <span className="col-span-2 text-slate-800">
                  {registration.age} Years · {registration.gender}
                </span>

                <span className="text-slate-500">Patient ID:</span>
                <span className="col-span-2 font-mono text-slate-700">
                  {registration.patientId}
                </span>

                <span className="text-slate-500">Mobile Phone:</span>
                <span className="col-span-2 font-mono text-slate-800">
                  {registration.mobileNumber}
                </span>

                <span className="text-slate-500">Address:</span>
                <span className="col-span-2 text-slate-700 text-[11px] leading-snug">
                  {registration.address}
                </span>
              </div>
            </div>

            {/* Consultation Details */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 pb-1 border-b border-slate-100">
                <Building2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Consultation Details</span>
              </div>
              <div className="grid grid-cols-3 gap-y-1.5 text-xs">
                <span className="text-slate-500">Department:</span>
                <span className="col-span-2 font-semibold text-sky-900">
                  {registration.departmentName}
                </span>

                <span className="text-slate-500">Doctor:</span>
                <span className="col-span-2 font-semibold text-slate-900">
                  {registration.doctorName}
                </span>

                <span className="text-slate-500">Room & Floor:</span>
                <span className="col-span-2 font-medium text-slate-800">
                  {registration.roomNumber} ({registration.floor})
                </span>

                <span className="text-slate-500">Reg. Type:</span>
                <span className="col-span-2 capitalize text-slate-800">
                  {registration.registrationType}
                </span>

                <span className="text-slate-500">Consultation Fee:</span>
                <span className="col-span-2 font-semibold text-slate-900">
                  ${registration.consultationFee}{' '}
                  <span className="text-[11px] font-normal text-emerald-700">
                    ({registration.paymentStatus})
                  </span>
                </span>
              </div>
            </div>
          </div>

          {/* Barcode & Registered Timestamp */}
          <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              {/* Barcode representation */}
              <div className="flex flex-col items-center">
                <div className="h-9 w-44 flex items-end justify-between px-1 bg-white border border-slate-300 py-1">
                  {[3, 1, 4, 1, 2, 4, 1, 3, 2, 1, 4, 2, 1, 3, 1, 4, 2, 3, 1, 2, 4, 1, 3, 2].map(
                    (w, idx) => (
                      <span
                        key={idx}
                        className="bg-slate-900 h-full inline-block"
                        style={{ width: `${w * 1.5}px` }}
                      />
                    )
                  )}
                </div>
                <span className="font-mono text-[10px] text-slate-600 tracking-widest mt-0.5">
                  *{registration.opNumber}*
                </span>
              </div>
              <div className="text-[11px] text-slate-500">
                <div>
                  Registered on:{' '}
                  <span className="font-medium text-slate-800">
                    {new Date(registration.registrationDate).toLocaleDateString()} at{' '}
                    {new Date(registration.registrationDate).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
                <div>
                  Counter Staff:{' '}
                  <span className="font-medium text-slate-700 capitalize">
                    {registration.registeredBy.replace('_', ' ')}
                  </span>
                </div>
              </div>
            </div>

            <div className="text-[10px] text-slate-500 text-right sm:max-w-xs leading-tight">
              <p className="font-semibold text-slate-700 mb-0.5">Patient Guidelines:</p>
              <p>• Please report to OPD Nursing Station 15 min prior.</p>
              <p>• Valid for 7 days for one follow-up check.</p>
            </div>
          </div>

          {/* Disclaimer Footer */}
          <div className="mt-4 pt-3 border-t border-dashed border-slate-300 text-center text-[10px] text-slate-500">
            DEMO SIMULATION SYSTEM: CareConnect is an educational simulation. Registrations are simulated for demo and queue management evaluation.
          </div>
        </div>

        {/* Modal Bottom Actions */}
        <div className="no-print bg-slate-50 px-6 py-3 border-t border-slate-200 flex items-center justify-between">
          <div className="text-xs text-slate-600 flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span>Keep your OP Number & Token handy when calling or visiting reception.</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
