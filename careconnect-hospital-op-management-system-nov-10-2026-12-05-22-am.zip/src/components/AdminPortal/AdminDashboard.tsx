import React, { useState, useEffect } from 'react';
import {
  Users,
  Activity,
  Calendar,
  Clock,
  Search,
  Filter,
  CheckCircle2,
  AlertCircle,
  FileText,
  UserCheck,
  Building2,
  Stethoscope,
  TrendingUp,
  RotateCcw,
  Plus,
  Printer,
  ChevronDown,
  ChevronRight,
  ShieldAlert,
  Download,
  Trash2,
  Edit2,
} from 'lucide-react';
import { api } from '../../api';
import {
  DashboardStats,
  Department,
  Doctor,
  OPRegistration,
  RegistrationStatus,
  StaffUser,
} from '../../types/index';

interface AdminDashboardProps {
  currentUser: StaffUser;
  departments: Department[];
  doctors: Doctor[];
  onRefreshData: () => void;
  onPrintSlip: (registration: OPRegistration) => void;
  onLogout: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  currentUser,
  departments,
  doctors,
  onRefreshData,
  onPrintSlip,
  onLogout,
}) => {
  const [activeSection, setActiveSection] = useState<'overview' | 'queue' | 'doctors' | 'departments'>('overview');
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loadingStats, setLoadingStats] = useState(false);

  // Queue state
  const [registrations, setRegistrations] = useState<OPRegistration[]>([]);
  const [loadingQueue, setLoadingQueue] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [deptFilter, setDeptFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<string>('all'); // 'all' | 'today' | specific date

  // Add Doctor Form Modal
  const [showAddDoctorModal, setShowAddDoctorModal] = useState(false);
  const [newDocName, setNewDocName] = useState('');
  const [newDocDeptId, setNewDocDeptId] = useState(departments[0]?.id || '');
  const [newDocQual, setNewDocQual] = useState('');
  const [newDocSpec, setNewDocSpec] = useState('');
  const [newDocExp, setNewDocExp] = useState(8);
  const [newDocRoom, setNewDocRoom] = useState('Room 215');
  const [newDocFloor, setNewDocFloor] = useState('2nd Floor, Wing B');
  const [newDocFee, setNewDocFee] = useState(450);
  const [newDocTimings, setNewDocTimings] = useState('09:00 AM - 01:00 PM | 03:00 PM - 05:00 PM');
  const [savingDoctor, setSavingDoctor] = useState(false);

  // Add Department Modal
  const [showAddDeptModal, setShowAddDeptModal] = useState(false);
  const [newDeptName, setNewDeptName] = useState('');
  const [newDeptCode, setNewDeptCode] = useState('');
  const [newDeptDesc, setNewDeptDesc] = useState('');
  const [newDeptFloor, setNewDeptFloor] = useState('1st Floor');
  const [newDeptWing, setNewDeptWing] = useState('Clinical Wing');
  const [newDeptHead, setNewDeptHead] = useState('Dr. Specialist');
  const [savingDept, setSavingDept] = useState(false);

  const [notification, setNotification] = useState<string | null>(null);

  const getTodayString = () => new Date().toISOString().split('T')[0];

  const fetchStatsAndQueue = async () => {
    setLoadingStats(true);
    setLoadingQueue(true);
    try {
      const [sData, rData] = await Promise.all([
        api.getDashboardStats(),
        api.getRegistrations(),
      ]);
      setStats(sData);
      setRegistrations(rData);
    } catch (err: any) {
      console.error('Failed to load dashboard data:', err);
    } finally {
      setLoadingStats(false);
      setLoadingQueue(false);
    }
  };

  useEffect(() => {
    fetchStatsAndQueue();
  }, []);

  const handleUpdateStatus = async (id: string, newStatus: RegistrationStatus) => {
    try {
      await api.updateRegistrationStatus(id, newStatus);
      setNotification(`Registration status successfully updated to "${newStatus}".`);
      fetchStatsAndQueue();
      setTimeout(() => setNotification(null), 3500);
    } catch (err: any) {
      alert(`Status update failed: ${err.message}`);
    }
  };

  const handleAddDoctor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocName.trim() || !newDocDeptId) return;

    setSavingDoctor(true);
    try {
      await api.addDoctor({
        name: newDocName.trim(),
        qualification: newDocQual.trim() || 'MD / MS Specialist',
        departmentId: newDocDeptId,
        specialization: newDocSpec.trim() || 'Clinical Consultant',
        experienceYears: newDocExp,
        roomNumber: newDocRoom,
        floor: newDocFloor,
        consultationFee: newDocFee,
        opdDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        opdTimings: newDocTimings,
      });

      setShowAddDoctorModal(false);
      setNewDocName('');
      setNewDocQual('');
      setNewDocSpec('');
      onRefreshData();
      fetchStatsAndQueue();
      setNotification(`New Doctor successfully added to outpatient roster!`);
      setTimeout(() => setNotification(null), 4000);
    } catch (err: any) {
      alert(`Failed to add doctor: ${err.message}`);
    } finally {
      setSavingDoctor(false);
    }
  };

  const handleDeleteDoctor = async (doctorId: string, doctorName: string) => {
    if (!confirm(`Are you sure you want to remove ${doctorName} from the hospital OPD roster?`)) {
      return;
    }
    try {
      await api.deleteDoctor(doctorId);
      onRefreshData();
      fetchStatsAndQueue();
      setNotification(`Doctor ${doctorName} has been removed from outpatient roster.`);
      setTimeout(() => setNotification(null), 3500);
    } catch (err: any) {
      alert(`Failed to delete doctor: ${err.message}`);
    }
  };

  const handleToggleDoctor = async (doctorId: string, currentAvail: boolean) => {
    try {
      await api.updateDoctor(doctorId, { isAvailable: !currentAvail });
      onRefreshData();
      setNotification(`Doctor OPD availability toggled to ${!currentAvail ? 'ACTIVE' : 'ON LEAVE'}.`);
      setTimeout(() => setNotification(null), 3000);
    } catch (err: any) {
      alert(`Failed to update doctor: ${err.message}`);
    }
  };

  const handleAddDepartment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDeptName.trim() || !newDeptCode.trim()) return;

    setSavingDept(true);
    try {
      await api.addDepartment({
        name: newDeptName.trim(),
        code: newDeptCode.trim().toUpperCase(),
        description: newDeptDesc.trim() || 'Specialized outpatient clinical care',
        floor: newDeptFloor,
        wing: newDeptWing,
        headDoctor: newDeptHead,
        iconName: 'Building2',
      });

      setShowAddDeptModal(false);
      setNewDeptName('');
      setNewDeptCode('');
      setNewDeptDesc('');
      onRefreshData();
      fetchStatsAndQueue();
      setNotification(`Department "${newDeptName}" successfully added.`);
      setTimeout(() => setNotification(null), 4000);
    } catch (err: any) {
      alert(`Failed to add department: ${err.message}`);
    } finally {
      setSavingDept(false);
    }
  };

  const handleDeleteDepartment = async (deptId: string, deptName: string) => {
    if (!confirm(`Are you sure you want to remove ${deptName}? Active doctors should be reassigned.`)) {
      return;
    }
    try {
      await api.deleteDepartment(deptId);
      onRefreshData();
      fetchStatsAndQueue();
      setNotification(`Department ${deptName} removed.`);
      setTimeout(() => setNotification(null), 3500);
    } catch (err: any) {
      alert(`Failed to delete department: ${err.message}`);
    }
  };

  const handleExportCSV = () => {
    if (filteredRegistrations.length === 0) {
      alert('No registrations available to export.');
      return;
    }

    const headers = [
      'OP Number',
      'Token Number',
      'Patient Name',
      'Age',
      'Gender',
      'Mobile Number',
      'Address',
      'Department',
      'Doctor',
      'Room',
      'Appointment Date',
      'Time Slot',
      'Registration Type',
      'Status',
      'Fee',
      'Payment Status',
    ];

    const rows = filteredRegistrations.map((r) => [
      `"${r.opNumber}"`,
      r.tokenNumber,
      `"${r.patientName.replace(/"/g, '""')}"`,
      r.age,
      r.gender,
      `"${r.mobileNumber}"`,
      `"${r.address.replace(/"/g, '""')}"`,
      `"${r.departmentName}"`,
      `"${r.doctorName}"`,
      `"${r.roomNumber}"`,
      r.appointmentDate,
      `"${r.appointmentTime}"`,
      r.registrationType,
      r.status,
      r.consultationFee,
      r.paymentStatus,
    ]);

    const csvContent = [headers.join(','), ...rows.map((row) => row.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `CareConnect_OP_Registrations_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleResetDemoData = async () => {
    if (
      !confirm(
        'Reset hospital database back to clean initial demo state? This will repopulate sample records and reset counters.'
      )
    ) {
      return;
    }
    try {
      await api.resetDemo();
      onRefreshData();
      fetchStatsAndQueue();
      setNotification('Hospital database reset to initial demonstration state.');
      setTimeout(() => setNotification(null), 4000);
    } catch (err: any) {
      alert(`Reset failed: ${err.message}`);
    }
  };

  // Filter queue
  const filteredRegistrations = registrations.filter((r) => {
    if (statusFilter !== 'all' && r.status !== statusFilter) return false;
    if (deptFilter !== 'all' && r.departmentId !== deptFilter) return false;
    if (typeFilter !== 'all' && r.registrationType !== typeFilter) return false;
    if (dateFilter === 'today' && r.appointmentDate !== getTodayString()) return false;
    if (dateFilter !== 'all' && dateFilter !== 'today' && r.appointmentDate !== dateFilter) return false;

    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        r.opNumber.toLowerCase().includes(q) ||
        r.patientName.toLowerCase().includes(q) ||
        r.mobileNumber.includes(q) ||
        r.doctorName.toLowerCase().includes(q) ||
        r.departmentName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Admin Banner */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase font-semibold tracking-wider text-sky-400">
              Hospital Executive Control Panel
            </span>
            <span className="text-[11px] bg-sky-500/20 text-sky-300 border border-sky-400/30 px-2 py-0.5 rounded font-mono">
              ADMIN
            </span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight text-white mt-1">
            CareConnect OP Management Console
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time analytics, queue control, doctor schedules & department volume
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Nav Segmented Buttons */}
          <div className="flex items-center p-1 bg-slate-800 rounded-xl border border-slate-700/80">
            <button
              onClick={() => setActiveSection('overview')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                activeSection === 'overview'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Overview & Analytics
            </button>
            <button
              onClick={() => setActiveSection('queue')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                activeSection === 'queue'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Patient Queue ({registrations.length})
            </button>
            <button
              onClick={() => setActiveSection('doctors')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                activeSection === 'doctors'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Doctors ({doctors.length})
            </button>
            <button
              onClick={() => setActiveSection('departments')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                activeSection === 'departments'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Departments ({departments.length})
            </button>
          </div>

          <button
            onClick={handleResetDemoData}
            title="Reset to clean demonstration state"
            className="p-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-colors cursor-pointer inline-flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Reset Demo</span>
          </button>

          <button
            onClick={onLogout}
            className="px-3.5 py-2 text-xs font-semibold text-rose-300 hover:text-white bg-slate-800 hover:bg-rose-900/60 border border-slate-700 rounded-xl transition-colors cursor-pointer"
          >
            Sign Out
          </button>
        </div>
      </div>

      {notification && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-medium">{notification}</span>
        </div>
      )}

      {/* SECTION 1: OVERVIEW & ANALYTICS */}
      {activeSection === 'overview' && stats && (
        <div className="space-y-6">
          {/* Key Metric KPI Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
              <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                Total Registrations
              </div>
              <div className="font-mono text-3xl font-bold text-slate-900 tabular-nums mt-1.5">
                {stats.totalRegistrations}
              </div>
              <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
                <span className="font-semibold text-sky-700 font-mono">
                  {stats.todayRegistrations} Today
                </span>
                <span>· All-time persistent</span>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
              <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                Online Registrations
              </div>
              <div className="font-mono text-3xl font-bold text-sky-800 tabular-nums mt-1.5">
                {stats.onlineRegistrations}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                Patients registered from home via portal
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
              <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                Walk-in Counter Registrations
              </div>
              <div className="font-mono text-3xl font-bold text-emerald-700 tabular-nums mt-1.5">
                {stats.walkinRegistrations}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                Hospital reception walk-in patients
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
              <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                Active Hospital Queue
              </div>
              <div className="font-mono text-3xl font-bold text-amber-700 tabular-nums mt-1.5">
                {stats.waitingCount + stats.inConsultationCount}
              </div>
              <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-2">
                <span className="text-amber-800 font-medium">
                  {stats.waitingCount} Waiting
                </span>
                <span>·</span>
                <span className="text-sky-700 font-medium">
                  {stats.inConsultationCount} In Room
                </span>
              </div>
            </div>
          </div>

          {/* Department-Wise Volume Distribution & Doctor Queue Roster */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Department Breakdown */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                    Department-wise Patient Count
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Distribution of outpatient volume across specialties
                  </p>
                </div>
                <Building2 className="w-4 h-4 text-sky-600" />
              </div>

              <div className="space-y-3">
                {stats.departmentCounts.map((dept) => {
                  const maxCount = Math.max(
                    ...stats.departmentCounts.map((d) => d.count),
                    1
                  );
                  const pct = Math.round((dept.count / maxCount) * 100);

                  return (
                    <div key={dept.departmentId} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-800">{dept.departmentName}</span>
                        <span className="font-mono font-bold text-slate-900 tabular-nums">
                          {dept.count} patient{dept.count === 1 ? '' : 's'}
                        </span>
                      </div>
                      <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-sky-600 rounded-full transition-all"
                          style={{ width: `${dept.count > 0 ? Math.max(pct, 12) : 0}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Doctor-wise Appointment & Queue List */}
            <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                    Doctor-wise Outpatient Appointment List
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Active tokens, waiting list, and completed consultations per doctor
                  </p>
                </div>
                <Stethoscope className="w-4 h-4 text-emerald-600" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {stats.doctorQueues.map((dq) => (
                  <div
                    key={dq.doctorId}
                    className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2 hover:bg-slate-100/70 transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-bold text-xs text-slate-900">{dq.doctorName}</h4>
                        <p className="text-[11px] text-slate-500">{dq.departmentName}</p>
                      </div>
                      <span className="text-[10px] font-mono font-semibold bg-white px-2 py-0.5 rounded border border-slate-200 text-slate-700">
                        {dq.roomNumber}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-200/80 text-center">
                      <div className="bg-white p-1.5 rounded-lg border border-slate-200/60">
                        <div className="text-[10px] text-slate-500 uppercase">Total</div>
                        <div className="font-mono text-xs font-bold text-slate-800">
                          {dq.totalToday}
                        </div>
                      </div>

                      <div className="bg-amber-50 p-1.5 rounded-lg border border-amber-200/60">
                        <div className="text-[10px] text-amber-800 uppercase">Waiting</div>
                        <div className="font-mono text-xs font-bold text-amber-900">
                          {dq.waiting}
                        </div>
                      </div>

                      <div className="bg-sky-50 p-1.5 rounded-lg border border-sky-200/60">
                        <div className="text-[10px] text-sky-800 uppercase">In Room</div>
                        <div className="font-mono text-xs font-bold text-sky-900">
                          {dq.currentToken ? `#${dq.currentToken}` : '—'}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: COMPREHENSIVE PATIENT QUEUE MANAGEMENT */}
      {activeSection === 'queue' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-5">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-slate-900">Patient Queue Management</h3>
              <p className="text-xs text-slate-500">
                Search by OP number, patient name, or mobile. Update status: Registered, Waiting, In
                Consultation, Completed, Cancelled.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleExportCSV}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export CSV</span>
              </button>

              <button
                onClick={fetchStatsAndQueue}
                className="text-xs font-semibold px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors cursor-pointer"
              >
                Refresh Table
              </button>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
            {/* Search */}
            <div className="sm:col-span-1 relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search OP, Name, Mobile..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>

            {/* Department Filter */}
            <div>
              <select
                value={deptFilter}
                onChange={(e) => setDeptFilter(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500 font-medium"
              >
                <option value="all">All Departments</option>
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Status Filter */}
            <div>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500 font-medium"
              >
                <option value="all">All Statuses</option>
                <option value="Registered">Registered</option>
                <option value="Waiting">Waiting</option>
                <option value="In Consultation">In Consultation</option>
                <option value="Completed">Completed</option>
                <option value="Cancelled">Cancelled</option>
              </select>
            </div>

            {/* Type Filter */}
            <div>
              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500 font-medium"
              >
                <option value="all">All Channels (Online + Walk-in)</option>
                <option value="online">Online Registration</option>
                <option value="walk-in">Reception Walk-in</option>
              </select>
            </div>

            {/* Date Filter */}
            <div>
              <select
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500 font-medium"
              >
                <option value="all">All Dates</option>
                <option value="today">Today's Date ({getTodayString()})</option>
              </select>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-700 uppercase font-bold text-[10px] tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">OP & Token</th>
                  <th className="px-4 py-3">Patient Details</th>
                  <th className="px-4 py-3">Clinical Assignment</th>
                  <th className="px-4 py-3">Slot & Date</th>
                  <th className="px-4 py-3">Channel & Fee</th>
                  <th className="px-4 py-3">Current Status</th>
                  <th className="px-4 py-3 text-right">Queue Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {filteredRegistrations.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-4 py-8 text-center text-slate-500">
                      No records match the selected search criteria.
                    </td>
                  </tr>
                ) : (
                  filteredRegistrations.map((reg) => (
                    <tr key={reg.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-4 py-3">
                        <div className="font-mono text-sm font-bold text-sky-900">
                          {reg.opNumber}
                        </div>
                        <div className="font-mono text-xs font-extrabold text-emerald-700">
                          Token #{reg.tokenNumber}
                        </div>
                      </td>

                      <td className="px-4 py-3">
                        <div className="font-bold text-slate-900">{reg.patientName}</div>
                        <div className="text-[11px] text-slate-500">
                          {reg.age}Y · {reg.gender} · {reg.mobileNumber}
                        </div>
                      </td>

                      <td className="px-4 py-3">
                        <div className="font-semibold text-slate-800">{reg.doctorName}</div>
                        <div className="text-[11px] text-sky-800">
                          {reg.departmentName} · {reg.roomNumber}
                        </div>
                      </td>

                      <td className="px-4 py-3">
                        <div className="font-medium text-slate-900">{reg.appointmentDate}</div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          {reg.appointmentTime}
                        </div>
                      </td>

                      <td className="px-4 py-3">
                        <span className="font-medium capitalize text-slate-800 block">
                          {reg.registrationType}
                        </span>
                        <span className="text-[11px] text-emerald-700 font-semibold font-mono">
                          ${reg.consultationFee} ({reg.paymentStatus})
                        </span>
                      </td>

                      <td className="px-4 py-3">
                        <select
                          value={reg.status}
                          onChange={(e) =>
                            handleUpdateStatus(reg.id, e.target.value as RegistrationStatus)
                          }
                          className={`text-xs font-bold px-2 py-1 rounded-md border cursor-pointer ${
                            reg.status === 'Waiting'
                              ? 'bg-amber-50 text-amber-900 border-amber-300'
                              : reg.status === 'In Consultation'
                              ? 'bg-sky-50 text-sky-900 border-sky-300'
                              : reg.status === 'Completed'
                              ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
                              : reg.status === 'Cancelled'
                              ? 'bg-rose-50 text-rose-900 border-rose-300'
                              : 'bg-slate-100 text-slate-800 border-slate-300'
                          }`}
                        >
                          <option value="Registered">Registered</option>
                          <option value="Waiting">Waiting</option>
                          <option value="In Consultation">In Consultation</option>
                          <option value="Completed">Completed</option>
                          <option value="Cancelled">Cancelled</option>
                        </select>
                      </td>

                      <td className="px-4 py-3 text-right">
                        <button
                          type="button"
                          onClick={() => onPrintSlip(reg)}
                          className="px-2.5 py-1 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors cursor-pointer inline-flex items-center gap-1"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>OP Slip</span>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SECTION 3: MANAGE DOCTORS */}
      {activeSection === 'doctors' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-5">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-slate-900">Hospital Medical Specialists Roster</h3>
              <p className="text-xs text-slate-500">
                Manage doctor availability, OPD consultation schedules, rooms, and fees
              </p>
            </div>

            <button
              onClick={() => setShowAddDoctorModal(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-sky-700 hover:bg-sky-600 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Doctor</span>
            </button>
          </div>

          {/* Doctors Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {doctors.map((doc) => (
              <div
                key={doc.id}
                className="p-5 rounded-2xl border border-slate-200 bg-slate-50/60 hover:bg-white transition-all space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-bold text-sm text-slate-900">{doc.name}</h4>
                    <p className="text-xs text-sky-800 font-semibold">{doc.departmentName}</p>
                    <p className="text-[11px] text-slate-500">{doc.qualification}</p>
                  </div>
                  <span
                    className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full border ${
                      doc.isAvailable
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                        : 'bg-rose-50 text-rose-800 border-rose-300'
                    }`}
                  >
                    {doc.isAvailable ? 'Active' : 'On Leave'}
                  </span>
                </div>

                <div className="text-xs text-slate-600 space-y-1 pt-2 border-t border-slate-200/70">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Specialization:</span>
                    <span className="font-medium text-slate-800 text-right truncate max-w-[170px]">
                      {doc.specialization}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Room & Floor:</span>
                    <span className="font-medium text-slate-800">
                      {doc.roomNumber} ({doc.floor})
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Consultation Fee:</span>
                    <span className="font-bold text-slate-900 font-mono">${doc.consultationFee}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">OPD Timings:</span>
                    <span className="font-medium text-slate-700 text-right text-[11px]">
                      {doc.opdTimings}
                    </span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200/70 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => handleDeleteDoctor(doc.id, doc.name)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
                    title="Remove doctor"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    type="button"
                    onClick={() => handleToggleDoctor(doc.id, doc.isAvailable)}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                      doc.isAvailable
                        ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200'
                        : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200'
                    }`}
                  >
                    {doc.isAvailable ? 'Mark on Leave' : 'Mark Available'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SECTION 4: MANAGE DEPARTMENTS */}
      {activeSection === 'departments' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-5">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-slate-900">Hospital Specialty Departments</h3>
              <p className="text-xs text-slate-500">
                Manage clinical departments, assigned floors, wings, and leadership
              </p>
            </div>

            <button
              onClick={() => setShowAddDeptModal(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-sky-700 hover:bg-sky-600 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Add Department</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {departments.map((dept) => {
              const assignedDocs = doctors.filter((d) => d.departmentId === dept.id);
              return (
                <div
                  key={dept.id}
                  className="p-5 rounded-2xl border border-slate-200 bg-slate-50/60 hover:bg-white transition-all space-y-3"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900">{dept.name}</h4>
                      <p className="text-xs text-sky-800 font-semibold">{dept.wing} · {dept.floor}</p>
                    </div>
                    <span className="text-[10px] font-mono font-bold bg-white px-2 py-0.5 rounded border border-slate-200 text-slate-700">
                      {dept.code}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {dept.description}
                  </p>

                  <div className="pt-2 border-t border-slate-200/70 text-xs text-slate-600 space-y-1">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Department Head:</span>
                      <span className="font-medium text-slate-800">{dept.headDoctor}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Specialists Assigned:</span>
                      <span className="font-bold text-sky-900">{assignedDocs.length} Doctor{assignedDocs.length === 1 ? '' : 's'}</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-200/70 flex justify-end">
                    <button
                      type="button"
                      onClick={() => handleDeleteDepartment(dept.id, dept.name)}
                      className="px-2.5 py-1 text-xs text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer inline-flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Remove</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Add Doctor Modal */}
      {showAddDoctorModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-4 border border-slate-200 shadow-2xl animate-in fade-in duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-base text-slate-900">Add New Consulting Doctor</h3>
              <button
                onClick={() => setShowAddDoctorModal(false)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddDoctor} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Doctor Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Dr. Arthur Pendelton"
                  value={newDocName}
                  onChange={(e) => setNewDocName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-1 focus:ring-sky-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Department</label>
                  <select
                    value={newDocDeptId}
                    onChange={(e) => setNewDocDeptId(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-1 focus:ring-sky-500"
                  >
                    {departments.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Qualification</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. MBBS, MD, FRCS"
                    value={newDocQual}
                    onChange={(e) => setNewDocQual(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Specialization</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Adult Interventional Cardiology"
                  value={newDocSpec}
                  onChange={(e) => setNewDocSpec(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Experience (Yrs)</label>
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={newDocExp}
                    onChange={(e) => setNewDocExp(parseInt(e.target.value, 10))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Room Number</label>
                  <input
                    type="text"
                    value={newDocRoom}
                    onChange={(e) => setNewDocRoom(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">OPD Fee ($)</label>
                  <input
                    type="number"
                    min="100"
                    max="2000"
                    value={newDocFee}
                    onChange={(e) => setNewDocFee(parseInt(e.target.value, 10))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Floor & Location</label>
                <input
                  type="text"
                  value={newDocFloor}
                  onChange={(e) => setNewDocFloor(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddDoctorModal(false)}
                  className="px-4 py-2 text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingDoctor}
                  className="px-5 py-2 bg-sky-700 hover:bg-sky-600 text-white font-semibold rounded-xl cursor-pointer"
                >
                  {savingDoctor ? 'Saving Doctor...' : 'Save Doctor'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Department Modal */}
      {showAddDeptModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-4 border border-slate-200 shadow-2xl animate-in fade-in duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-base text-slate-900">Add Specialty Department</h3>
              <button
                onClick={() => setShowAddDeptModal(false)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddDepartment} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Department Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Ophthalmology"
                    value={newDeptName}
                    onChange={(e) => setNewDeptName(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Code</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. OPHTH"
                    value={newDeptCode}
                    onChange={(e) => setNewDeptCode(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl uppercase font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Clinical Scope & Description</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Comprehensive vision testing, cataract consultations, and eye care..."
                  value={newDeptDesc}
                  onChange={(e) => setNewDeptDesc(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Floor</label>
                  <input
                    type="text"
                    value={newDeptFloor}
                    onChange={(e) => setNewDeptFloor(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Wing</label>
                  <input
                    type="text"
                    value={newDeptWing}
                    onChange={(e) => setNewDeptWing(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Head Specialist</label>
                  <input
                    type="text"
                    value={newDeptHead}
                    onChange={(e) => setNewDeptHead(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddDeptModal(false)}
                  className="px-4 py-2 text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingDept}
                  className="px-5 py-2 bg-sky-700 hover:bg-sky-600 text-white font-semibold rounded-xl cursor-pointer"
                >
                  {savingDept ? 'Creating...' : 'Create Department'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
