import React, { useState } from 'react';
import {
  Sparkles,
  AlertTriangle,
  X,
  ArrowRight,
  ShieldAlert,
  HelpCircle,
  Stethoscope,
  Info,
  Loader2,
} from 'lucide-react';
import { api } from '../../api';
import { AISymptomSuggestion, Gender } from '../../types/index';

interface SymptomAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectDepartment: (departmentId: string) => void;
  initialAge?: number;
  initialGender?: Gender;
}

const SAMPLE_SYMPTOMS = [
  'Chest heaviness and shortness of breath when walking up stairs',
  'Severe knee pain and stiffness in the morning',
  'Child has fever, body rash, and loss of appetite for 2 days',
  'Persistent throbbing headache on right side with sensitivity to light',
  'Ear discharge and severe ear pain for 48 hours',
  'Itchy red patches on arms and back with skin flaking',
];

export const SymptomAssistantModal: React.FC<SymptomAssistantModalProps> = ({
  isOpen,
  onClose,
  onSelectDepartment,
  initialAge,
  initialGender,
}) => {
  const [symptoms, setSymptoms] = useState('');
  const [age, setAge] = useState<number | undefined>(initialAge);
  const [gender, setGender] = useState<Gender | undefined>(initialGender);
  const [loading, setLoading] = useState(false);
  const [suggestion, setSuggestion] = useState<AISymptomSuggestion | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAnalyze = async () => {
    if (!symptoms.trim() || symptoms.trim().length < 4) {
      setError('Please describe your symptoms in at least a few words.');
      return;
    }
    setError(null);
    setLoading(true);

    try {
      const res = await api.getAISymptomSuggestion(symptoms, age, gender);
      setSuggestion(res);
    } catch (err: any) {
      setError(err.message || 'Unable to analyze symptoms at this moment.');
    } finally {
      setLoading(false);
    }
  };

  const handleApply = () => {
    if (suggestion) {
      onSelectDepartment(suggestion.matchedDepartmentId);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-sky-900 via-sky-800 to-teal-800 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/10 rounded-lg backdrop-blur-md">
              <Sparkles className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h3 className="font-bold text-base tracking-tight">AI Outpatient Department Assistant</h3>
              <p className="text-xs text-sky-200">
                Describe your symptoms in plain words for intelligent clinic routing
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-sky-200 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {/* Strict Medical Disclaimer Notice */}
          <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-xs flex items-start gap-3">
            <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <span className="font-semibold text-amber-950 block">Important Clinical Notice:</span>
              <p className="leading-relaxed">
                This AI assistant is an educational triage guide designed solely to recommend the most suitable outpatient specialty department.
                <strong> It does not provide a medical diagnosis and never prescribes medication or replaces a licensed doctor’s consultation.</strong>
              </p>
            </div>
          </div>

          {/* Symptom Input Form */}
          <div className="space-y-3">
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider">
              Describe your health concern or symptoms
            </label>
            <textarea
              rows={3}
              value={symptoms}
              onChange={(e) => setSymptoms(e.target.value)}
              placeholder="e.g., I have been feeling dull chest tightness when walking fast, and my heart feels like it races intermittently..."
              className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors"
            />

            {/* Quick Sample Chips */}
            <div>
              <span className="text-[11px] font-medium text-slate-500 block mb-1.5">
                Quick examples to try:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {SAMPLE_SYMPTOMS.map((sample, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setSymptoms(sample)}
                    className="text-[11px] text-slate-600 bg-slate-100 hover:bg-sky-50 hover:text-sky-700 hover:border-sky-200 border border-slate-200 px-2.5 py-1 rounded-md transition-colors cursor-pointer text-left"
                  >
                    {sample}
                  </button>
                ))}
              </div>
            </div>

            {/* Age & Gender context inputs */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-[11px] font-medium text-slate-600 mb-1">
                  Patient Age (Optional)
                </label>
                <input
                  type="number"
                  min="0"
                  max="120"
                  value={age ?? ''}
                  onChange={(e) => setAge(e.target.value ? parseInt(e.target.value, 10) : undefined)}
                  placeholder="e.g. 35"
                  className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-1 focus:ring-sky-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-600 mb-1">
                  Gender (Optional)
                </label>
                <select
                  value={gender || ''}
                  onChange={(e) => setGender((e.target.value as Gender) || undefined)}
                  className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-1 focus:ring-sky-500 focus:outline-none"
                >
                  <option value="">Select gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            {error && (
              <div className="text-xs text-rose-600 bg-rose-50 border border-rose-200 rounded-lg p-2.5 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div className="pt-2 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={onClose}
                className="text-xs text-slate-500 hover:text-slate-800 font-medium transition-colors"
              >
                Skip AI assistance & choose manually
              </button>

              <button
                type="button"
                onClick={handleAnalyze}
                disabled={loading || !symptoms.trim()}
                className="inline-flex items-center gap-2 px-4 py-2 bg-sky-700 hover:bg-sky-600 disabled:opacity-50 text-white text-xs font-semibold rounded-xl shadow-sm transition-colors cursor-pointer"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Analyzing clinical patterns...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    <span>Get Department Recommendation</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* AI Output Card */}
          {suggestion && (
            <div className="mt-4 p-4 bg-sky-50/70 border border-sky-200 rounded-xl space-y-3.5 animate-in fade-in duration-200">
              {suggestion.isUrgentCareNeeded && (
                <div className="p-3 bg-rose-100 border border-rose-300 rounded-lg text-rose-900 text-xs font-medium flex items-start gap-2">
                  <ShieldAlert className="w-4 h-4 text-rose-700 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block">Urgent Care Warning:</span>
                    {suggestion.urgencyWarning}
                  </div>
                </div>
              )}

              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                    Recommended Outpatient Department
                  </div>
                  <div className="text-lg font-bold text-sky-950 flex items-center gap-2 mt-0.5">
                    <Stethoscope className="w-5 h-5 text-sky-700" />
                    <span>{suggestion.suggestedDepartment}</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleApply}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer shrink-0"
                >
                  <span>Select & Apply</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="text-xs text-slate-700 leading-relaxed bg-white/70 p-3 rounded-lg border border-sky-100">
                <span className="font-semibold text-slate-900 block mb-1">Reason for recommendation:</span>
                {suggestion.explanation}
              </div>

              {suggestion.suggestedQuestions && suggestion.suggestedQuestions.length > 0 && (
                <div className="space-y-1.5">
                  <span className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
                    <HelpCircle className="w-3.5 h-3.5 text-sky-600" />
                    Suggested questions to ask your doctor in OPD:
                  </span>
                  <ul className="text-xs text-slate-600 space-y-1 pl-5 list-disc">
                    {suggestion.suggestedQuestions.map((q, idx) => (
                      <li key={idx}>{q}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="text-[11px] text-slate-500 italic pt-1 border-t border-sky-100">
                {suggestion.disclaimer}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
