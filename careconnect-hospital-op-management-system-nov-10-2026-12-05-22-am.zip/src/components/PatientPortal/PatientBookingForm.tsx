import React, { useState, useEffect } from 'react';
import {
  User,
  Calendar,
  Clock,
  Sparkles,
  Stethoscope,
  Building2,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  ArrowLeft,
  Search,
  ShieldCheck,
  CreditCard,
  MapPin,
  Phone,
} from 'lucide-react';
import { api } from '../../api';
import {
  Department,
  Doctor,
  Gender,
  OPRegistration,
  HospitalInfo,
} from '../../types/index';
import { SymptomAssistantModal } from './SymptomAssistantModal';
import { PatientLookupModal } from './PatientLookupModal';

interface PatientBookingFormProps {
  hospitalInfo: HospitalInfo | null;
  departments: Department[];
  onRegistrationSuccess: (registration: OPRegistration) => void;
}

export const PatientBookingForm: React.FC<PatientBookingFormProps> = ({
  hospitalInfo,
  departments,
  onRegistrationSuccess,
}) => {
  // Wizard steps: 1 = Patient Details, 2 = Department & Doctor, 3 = Date & Slot & Review
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3>(1);

  // Form fields
  const [fullName, setFullName] = useState('');
  const [age, setAge] = useState<number | ''>('');
  const [gender, setGender] = useState<Gender>('Male');
  const [mobileNumber, setMobileNumber] = useState('');
  const [address, setAddress] = useState('');
  const [bloodGroup, setBloodGroup] = useState('');

  const [selectedDeptId, setSelectedDeptId] = useState<string>('');
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>('');

  // Date defaults to today or tomorrow
  const getTomorrowString = () => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().split('T')[0];
  };

  const getTodayString = () => new Date().toISOString().split('T')[0];

  const [appointmentDate, setAppointmentDate] = useState<string>(getTodayString());
  const [slots, setSlots] = useState<{ time: string; isBooked: boolean }[]>([]);
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>('');
  const [symptomsNotes, setSymptomsNotes] = useState('');

  // States & Modals
  const [loadingDoctors, setLoadingDoctors] = useState(false);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [showAiModal, setShowAiModal] = useState(false);
  const [showLookupModal, setShowLookupModal] = useState(false);

  // Auto-select first department when departments load
  useEffect(() => {
    if (departments.length > 0 && !selectedDeptId) {
      setSelectedDeptId(departments[0].id);
    }
  }, [departments, selectedDeptId]);

  // Load doctors whenever selected department changes
  useEffect(() => {
    if (!selectedDeptId) return;

    let isMounted = true;
    setLoadingDoctors(true);
    setSelectedDoctorId('');

    api
      .getDoctors(selectedDeptId)
      .then((docs) => {
        if (isMounted) {
          setDoctors(docs);
          if (docs.length > 0) {
            setSelectedDoctorId(docs[0].id);
          }
        }
      })
      .catch((err) => {
        console.error('Failed to load doctors:', err);
      })
      .finally(() => {
        if (isMounted) setLoadingDoctors(false);
      });

    return () => {
      isMounted = false;
    };
  }, [selectedDeptId]);

  // Load slots whenever doctor or appointment date changes
  useEffect(() => {
    if (!selectedDoctorId || !appointmentDate) return;

    let isMounted = true;
    setLoadingSlots(true);
    setSelectedTimeSlot('');

    api
      .getDoctorSlots(selectedDoctorId, appointmentDate)
      .then((slotList) => {
        if (isMounted) {
          setSlots(slotList);
          // Auto select first available slot
          const firstAvailable = slotList.find((s) => !s.isBooked);
          if (firstAvailable) {
            setSelectedTimeSlot(firstAvailable.time);
          }
        }
      })
      .catch((err) => {
        console.error('Failed to load slots:', err);
      })
      .finally(() => {
        if (isMounted) setLoadingSlots(false);
      });

    return () => {
      isMounted = false;
    };
  }, [selectedDoctorId, appointmentDate]);

  const selectedDoctor = doctors.find((d) => d.id === selectedDoctorId);
  const selectedDept = departments.find((d) => d.id === selectedDeptId);

  // Validation
  const validateStep1 = () => {
    if (!fullName.trim()) return 'Please enter patient full name';
    if (!age || Number(age) <= 0 || Number(age) > 125) return 'Please enter a valid age';
    const cleanPhone = mobileNumber.replace(/\D/g, '');
    if (cleanPhone.length < 10) return 'Please enter a valid 10-digit mobile number';
    if (!address.trim()) return 'Please enter patient residential address';
    return null;
  };

  const validateStep2 = () => {
    if (!selectedDeptId) return 'Please select a department';
    if (!selectedDoctorId) return 'Please select an available doctor';
    return null;
  };

  const validateStep3 = () => {
    if (!appointmentDate) return 'Please select appointment date';
    if (!selectedTimeSlot) return 'Please choose an available appointment time slot';
    return null;
  };

  const handleNext = () => {
    setErrorMessage(null);
    if (currentStep === 1) {
      const err = validateStep1();
      if (err) {
        setErrorMessage(err);
        return;
      }
      setCurrentStep(2);
    } else if (currentStep === 2) {
      const err = validateStep2();
      if (err) {
        setErrorMessage(err);
        return;
      }
      setCurrentStep(3);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const err = validateStep3();
    if (err) {
      setErrorMessage(err);
      return;
    }

    setSubmitting(true);
    try {
      const response = await api.registerOnline({
        fullName: fullName.trim(),
        age: Number(age),
        gender,
        mobileNumber: mobileNumber.trim(),
        address: address.trim(),
        bloodGroup: bloodGroup || undefined,
        departmentId: selectedDeptId,
        doctorId: selectedDoctorId,
        appointmentDate,
        appointmentTime: selectedTimeSlot,
        symptomsNotes: symptomsNotes.trim() || undefined,
      });

      onRegistrationSuccess(response.registration);
    } catch (err: any) {
      setErrorMessage(err.message || 'Registration failed. Please check inputs and try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Quick Actions */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-sky-800 uppercase tracking-wider mb-1">
            <Building2 className="w-4 h-4 text-sky-600" />
            <span>Online Patient Portal · Register From Home</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight text-slate-900">
            Book Outpatient (OP) Consultation
          </h2>
          <p className="text-xs text-slate-500 mt-1 max-w-xl">
            Register online before visiting to skip reception queues. Instant unique OP registration
            number and token allocated immediately.
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0 w-full sm:w-auto">
          <button
            type="button"
            onClick={() => setShowLookupModal(true)}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-xl transition-colors cursor-pointer"
          >
            <Search className="w-3.5 h-3.5 text-slate-500" />
            <span>Check Existing OP Status</span>
          </button>

          <button
            type="button"
            onClick={() => setShowAiModal(true)}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-sky-900 bg-sky-50 hover:bg-sky-100 border border-sky-200 rounded-xl transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>AI Symptom Assistant</span>
          </button>
        </div>
      </div>

      {/* Stepper Progress Bar */}
      <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs">
        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => setCurrentStep(1)}
            className={`text-left p-2.5 rounded-lg transition-colors cursor-pointer ${
              currentStep === 1
                ? 'bg-sky-50 border border-sky-300 text-sky-900'
                : 'hover:bg-slate-50 text-slate-600'
            }`}
          >
            <div className="flex items-center gap-2">
              <span
                className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] font-bold ${
                  currentStep === 1 ? 'bg-sky-700 text-white' : 'bg-slate-200 text-slate-700'
                }`}
              >
                1
              </span>
              <span className="text-xs font-semibold">Patient Information</span>
            </div>
            <span className="text-[11px] text-slate-500 block ml-7 mt-0.5">Demographics & contact</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (!validateStep1()) setCurrentStep(2);
            }}
            className={`text-left p-2.5 rounded-lg transition-colors cursor-pointer ${
              currentStep === 2
                ? 'bg-sky-50 border border-sky-300 text-sky-900'
                : 'hover:bg-slate-50 text-slate-600'
            }`}
          >
            <div className="flex items-center gap-2">
              <span
                className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] font-bold ${
                  currentStep === 2 ? 'bg-sky-700 text-white' : 'bg-slate-200 text-slate-700'
                }`}
              >
                2
              </span>
              <span className="text-xs font-semibold">Department & Doctor</span>
            </div>
            <span className="text-[11px] text-slate-500 block ml-7 mt-0.5">Specialist selection</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (!validateStep1() && !validateStep2()) setCurrentStep(3);
            }}
            className={`text-left p-2.5 rounded-lg transition-colors cursor-pointer ${
              currentStep === 3
                ? 'bg-sky-50 border border-sky-300 text-sky-900'
                : 'hover:bg-slate-50 text-slate-600'
            }`}
          >
            <div className="flex items-center gap-2">
              <span
                className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] font-bold ${
                  currentStep === 3 ? 'bg-sky-700 text-white' : 'bg-slate-200 text-slate-700'
                }`}
              >
                3
              </span>
              <span className="text-xs font-semibold">Slot & Confirm</span>
            </div>
            <span className="text-[11px] text-slate-500 block ml-7 mt-0.5">Token generation</span>
          </button>
        </div>
      </div>

      {/* Error alert if any */}
      {errorMessage && (
        <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2.5">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span className="font-medium">{errorMessage}</span>
        </div>
      )}

      {/* Multi-Step Form */}
      <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 md:p-8 border border-slate-200 shadow-sm">
        {/* STEP 1: PATIENT INFORMATION */}
        {currentStep === 1 && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div>
              <h3 className="text-base font-bold text-slate-900">Step 1: Patient Demographic Details</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Provide accurate details. These will be officially printed on your OP registration slip.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Full Name of Patient <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    required
                    placeholder="e.g. Eleanor Vance"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full pl-10 pr-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Age (Years) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="number"
                  min="0"
                  max="125"
                  required
                  placeholder="e.g. 34"
                  value={age}
                  onChange={(e) => setAge(e.target.value ? parseInt(e.target.value, 10) : '')}
                  className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Gender <span className="text-rose-500">*</span>
                </label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value as Gender)}
                  className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Mobile Phone Number <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="tel"
                    required
                    placeholder="e.g. 9876543210"
                    value={mobileNumber}
                    onChange={(e) => setMobileNumber(e.target.value)}
                    className="w-full pl-10 pr-3.5 py-2.5 text-sm font-mono bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                </div>
                <span className="text-[11px] text-slate-500 mt-1 block">
                  Used along with OP Number to verify and download your slip anytime.
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Blood Group (Optional)
                </label>
                <select
                  value={bloodGroup}
                  onChange={(e) => setBloodGroup(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                >
                  <option value="">Unknown / Not sure</option>
                  <option value="A+">A+</option>
                  <option value="A-">A-</option>
                  <option value="B+">B+</option>
                  <option value="B-">B-</option>
                  <option value="O+">O+</option>
                  <option value="O-">O-</option>
                  <option value="AB+">AB+</option>
                  <option value="AB-">AB-</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Residential Address <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <textarea
                    rows={2}
                    required
                    placeholder="House/Flat number, Street, Locality, City, State"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full pl-10 pr-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t border-slate-200">
              <button
                type="button"
                onClick={handleNext}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-sky-700 hover:bg-sky-600 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                <span>Continue to Department & Doctor</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: DEPARTMENT & DOCTOR SELECTION */}
        {currentStep === 2 && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-slate-900">Step 2: Department & Consulting Doctor</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Select the appropriate clinical department and doctor for your consultation.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setShowAiModal(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-sky-800 bg-sky-50 hover:bg-sky-100 border border-sky-300 rounded-lg transition-colors cursor-pointer shrink-0"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>Need help choosing? Ask AI Assistant</span>
              </button>
            </div>

            {/* Department Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
                Hospital Specialty Departments ({departments.length})
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {departments.map((dept) => {
                  const isSelected = dept.id === selectedDeptId;
                  return (
                    <button
                      key={dept.id}
                      type="button"
                      onClick={() => setSelectedDeptId(dept.id)}
                      className={`p-3 text-left rounded-xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-sky-50 border-sky-600 ring-2 ring-sky-600/20 text-sky-950'
                          : 'bg-slate-50 border-slate-200 hover:border-slate-300 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs">{dept.name}</span>
                        {isSelected && <CheckCircle2 className="w-4 h-4 text-sky-600 shrink-0" />}
                      </div>
                      <span className="text-[11px] text-slate-500 block mt-1 line-clamp-1">
                        {dept.floor}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Doctor Selection for chosen department */}
            <div className="pt-2">
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
                Available Doctors in {selectedDept?.name}
              </label>

              {loadingDoctors ? (
                <div className="p-8 text-center text-xs text-slate-500 bg-slate-50 rounded-xl border border-slate-200">
                  Loading specialists schedule...
                </div>
              ) : doctors.length === 0 ? (
                <div className="p-8 text-center text-xs text-amber-800 bg-amber-50 rounded-xl border border-amber-200">
                  No active doctors available in this department today. Please choose another department.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {doctors.map((doc) => {
                    const isSelected = doc.id === selectedDoctorId;
                    return (
                      <div
                        key={doc.id}
                        onClick={() => setSelectedDoctorId(doc.id)}
                        className={`p-4 rounded-xl border cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-sky-50/70 border-sky-600 ring-2 ring-sky-600/20 shadow-xs'
                            : 'bg-white border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <h4 className="font-bold text-sm text-slate-900">{doc.name}</h4>
                            <p className="text-xs text-sky-800 font-medium">{doc.qualification}</p>
                            <p className="text-[11px] text-slate-500 mt-1">{doc.specialization}</p>
                          </div>
                          {isSelected && <CheckCircle2 className="w-5 h-5 text-sky-600 shrink-0" />}
                        </div>

                        <div className="mt-3 pt-2.5 border-t border-slate-200/70 flex items-center justify-between text-xs text-slate-600">
                          <div>
                            <span className="font-semibold text-slate-800">{doc.roomNumber}</span> ·{' '}
                            <span>{doc.floor}</span>
                          </div>
                          <div className="font-bold text-slate-900">${doc.consultationFee}</div>
                        </div>

                        <div className="text-[11px] text-slate-500 mt-1">
                          OPD Timings: <span className="text-slate-700">{doc.opdTimings}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setCurrentStep(1)}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back to Patient Details</span>
              </button>

              <button
                type="button"
                onClick={handleNext}
                disabled={!selectedDoctorId}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-sky-700 hover:bg-sky-600 disabled:opacity-50 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                <span>Continue to Date & Slot</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: DATE, SLOT & CONFIRMATION */}
        {currentStep === 3 && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div>
              <h3 className="text-base font-bold text-slate-900">Step 3: Appointment Date & Time Slot</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Pick your preferred consultation time slot. Your token will be allocated sequentially.
              </p>
            </div>

            {/* Date Picker */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-1">
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Appointment Date <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="date"
                    min={getTodayString()}
                    value={appointmentDate}
                    onChange={(e) => setAppointmentDate(e.target.value)}
                    className="w-full pl-10 pr-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                    required
                  />
                </div>
                <div className="mt-2 flex gap-1.5">
                  <button
                    type="button"
                    onClick={() => setAppointmentDate(getTodayString())}
                    className="text-[11px] text-sky-700 bg-sky-50 hover:bg-sky-100 px-2.5 py-1 rounded-md border border-sky-200 transition-colors cursor-pointer"
                  >
                    Today
                  </button>
                  <button
                    type="button"
                    onClick={() => setAppointmentDate(getTomorrowString())}
                    className="text-[11px] text-slate-600 bg-slate-100 hover:bg-slate-200 px-2.5 py-1 rounded-md border border-slate-200 transition-colors cursor-pointer"
                  >
                    Tomorrow
                  </button>
                </div>
              </div>

              {/* Slot Picker */}
              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Select Time Slot for {selectedDoctor?.name} <span className="text-rose-500">*</span>
                </label>

                {loadingSlots ? (
                  <div className="p-6 text-center text-xs text-slate-500 bg-slate-50 rounded-xl border border-slate-200">
                    Checking slot availability...
                  </div>
                ) : (
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                    {slots.map((s) => {
                      const isSelected = selectedTimeSlot === s.time;
                      return (
                        <button
                          key={s.time}
                          type="button"
                          disabled={s.isBooked}
                          onClick={() => setSelectedTimeSlot(s.time)}
                          className={`py-2 px-2 text-center rounded-lg text-xs font-mono transition-all cursor-pointer ${
                            s.isBooked
                              ? 'bg-slate-100 text-slate-400 line-through cursor-not-allowed border border-slate-200'
                              : isSelected
                              ? 'bg-emerald-600 text-white font-bold ring-2 ring-emerald-500/30'
                              : 'bg-slate-50 border border-slate-200 hover:border-slate-300 text-slate-800'
                          }`}
                        >
                          {s.time}
                        </button>
                      );
                    })}
                  </div>
                )}
                <div className="flex items-center gap-4 text-[11px] text-slate-500 mt-2">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-sm bg-slate-50 border border-slate-300 inline-block" />
                    <span>Available</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-sm bg-emerald-600 inline-block" />
                    <span>Selected</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-sm bg-slate-100 border border-slate-200 inline-block" />
                    <span className="line-through text-slate-400">Booked</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Optional Symptoms / Reason for visit */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Brief Reason for Consultation / Symptoms (Optional)
              </label>
              <textarea
                rows={2}
                placeholder="e.g. Follow-up consultation for blood pressure check, or knee pain symptoms..."
                value={symptomsNotes}
                onChange={(e) => setSymptomsNotes(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>

            {/* Final Booking Summary Card */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center justify-between">
                <span>OP Registration Summary</span>
                <span className="text-[11px] font-normal text-slate-500">
                  Ready to generate official OP Slip
                </span>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs pt-1 border-t border-slate-200/80">
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Patient</span>
                  <span className="font-semibold text-slate-900">{fullName}</span>
                  <span className="text-slate-500 text-[11px] block">
                    {age} Yrs · {gender}
                  </span>
                </div>

                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Doctor & Clinic</span>
                  <span className="font-semibold text-sky-900">{selectedDoctor?.name}</span>
                  <span className="text-slate-500 text-[11px] block">{selectedDept?.name}</span>
                </div>

                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Date & Time</span>
                  <span className="font-semibold text-slate-900">{appointmentDate}</span>
                  <span className="text-emerald-700 font-mono text-[11px] block font-medium">
                    {selectedTimeSlot || 'Not selected'}
                  </span>
                </div>

                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Consultation Fee</span>
                  <span className="font-bold text-slate-900 text-sm">
                    ${selectedDoctor?.consultationFee || 400}
                  </span>
                  <span className="text-[11px] text-emerald-700 block">Online E-Pass Confirmed</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setCurrentStep(2)}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back to Doctor Selection</span>
              </button>

              <button
                type="submit"
                disabled={submitting || !selectedTimeSlot}
                className="inline-flex items-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-sm transition-colors cursor-pointer"
              >
                {submitting ? (
                  <span>Generating OP Slip...</span>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Confirm & Generate OP Slip</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </form>

      {/* AI Symptom Assistant Modal */}
      <SymptomAssistantModal
        isOpen={showAiModal}
        onClose={() => setShowAiModal(false)}
        initialAge={typeof age === 'number' ? age : undefined}
        initialGender={gender}
        onSelectDepartment={(deptId) => {
          setSelectedDeptId(deptId);
          setCurrentStep(2);
        }}
      />

      {/* Check Status Modal */}
      <PatientLookupModal
        isOpen={showLookupModal}
        onClose={() => setShowLookupModal(false)}
        onViewSlip={(reg) => {
          setShowLookupModal(false);
          onRegistrationSuccess(reg);
        }}
      />
    </div>
  );
};
