import React, { useState } from 'react';
import { Search, X, AlertCircle, FileText, CheckCircle2, Clock, Calendar, ArrowRight } from 'lucide-react';
import { api } from '../../api';
import { OPRegistration } from '../../types/index';

interface PatientLookupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onViewSlip: (registration: OPRegistration) => void;
}

export const PatientLookupModal: React.FC<PatientLookupModalProps> = ({
  isOpen,
  onClose,
  onViewSlip,
}) => {
  const [opNumber, setOpNumber] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<OPRegistration | null>(null);

  if (!isOpen) return null;

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!opNumber.trim() || !mobileNumber.trim()) {
      setError('Please enter both OP Number and registered mobile number.');
      return;
    }

    setError(null);
    setLoading(true);
    setResult(null);

    try {
      const reg = await api.lookupRegistration(opNumber.trim(), mobileNumber.trim());
      setResult(reg);
    } catch (err: any) {
      setError(err.message || 'No matching record found. Please verify the OP number and mobile.');
    } finally {
      setLoading(false);
    }
  };

  const handleFillDemo = (demoOp: string, demoPhone: string) => {
    setOpNumber(demoOp);
    setMobileNumber(demoPhone);
    setError(null);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Search className="w-5 h-5 text-sky-400" />
            <div>
              <h3 className="font-bold text-base">Check OP Registration Status</h3>
              <p className="text-xs text-slate-400">Search with your OP Number and registered mobile</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-4">
          <form onSubmit={handleSearch} className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                OP Registration Number
              </label>
              <input
                type="text"
                placeholder="e.g. CC-2026-1001"
                value={opNumber}
                onChange={(e) => setOpNumber(e.target.value.toUpperCase())}
                className="w-full px-3.5 py-2 text-sm font-mono bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500 uppercase"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Registered Mobile Number
              </label>
              <input
                type="tel"
                placeholder="e.g. 9876543210"
                value={mobileNumber}
                onChange={(e) => setMobileNumber(e.target.value)}
                className="w-full px-3.5 py-2 text-sm font-mono bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                required
              />
            </div>

            {error && (
              <div className="text-xs text-rose-700 bg-rose-50 border border-rose-200 p-2.5 rounded-lg flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-sky-700 hover:bg-sky-600 disabled:opacity-50 text-white font-semibold text-xs rounded-xl shadow-sm transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              {loading ? 'Verifying with hospital records...' : 'Find Registration Record'}
            </button>
          </form>

          {/* Quick Demo Pre-fills */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600">
            <span className="font-semibold text-slate-700 block mb-1">Quick Demo Lookups:</span>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => handleFillDemo('CC-2026-1001', '9876543210')}
                className="text-[11px] bg-white border border-slate-300 hover:border-sky-400 px-2 py-1 rounded text-slate-700 cursor-pointer"
              >
                Emily Watson (Cardiology)
              </button>
              <button
                type="button"
                onClick={() => handleFillDemo('CC-2026-1002', '9811223344')}
                className="text-[11px] bg-white border border-slate-300 hover:border-sky-400 px-2 py-1 rounded text-slate-700 cursor-pointer"
              >
                Rajesh Verma (Orthopedics)
              </button>
            </div>
          </div>

          {/* Search Result Card */}
          {result && (
            <div className="p-4 bg-sky-50/80 border border-sky-200 rounded-xl space-y-3 animate-in fade-in duration-200">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-base font-bold text-sky-950">
                      {result.opNumber}
                    </span>
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                      Token #{result.tokenNumber}
                    </span>
                  </div>
                  <div className="text-xs font-semibold text-slate-800 mt-0.5">
                    {result.patientName} ({result.age}y · {result.gender})
                  </div>
                </div>

                <div className="text-right">
                  <span className="inline-block text-[11px] font-semibold px-2.5 py-1 rounded-md bg-white border border-slate-200 text-slate-700 shadow-2xs">
                    Status: <span className="text-sky-700">{result.status}</span>
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs text-slate-700 pt-2 border-t border-sky-100">
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Department</span>
                  <span className="font-medium text-slate-900">{result.departmentName}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Doctor & Room</span>
                  <span className="font-medium text-slate-900">
                    {result.doctorName} ({result.roomNumber})
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Appointment</span>
                  <span className="font-medium text-slate-900">
                    {result.appointmentDate} · {result.appointmentTime}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Registration Mode</span>
                  <span className="font-medium capitalize text-slate-900">
                    {result.registrationType}
                  </span>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => onViewSlip(result)}
                  className="w-full py-2 bg-sky-700 hover:bg-sky-600 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>View & Print Official OP Slip</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
