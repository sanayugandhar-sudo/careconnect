import React from 'react';
import {
  HeartPulse,
  Activity,
  Baby,
  Stethoscope,
  Brain,
  Ear,
  Sparkles,
  UserCheck,
  Building2,
  Clock,
  ArrowRight,
} from 'lucide-react';
import { Department, Doctor } from '../types/index';

interface DepartmentDirectoryProps {
  departments: Department[];
  doctors: Doctor[];
  onSelectDepartment: (deptId: string) => void;
}

const DEPT_ICONS: Record<string, React.ReactNode> = {
  HeartPulse: <HeartPulse className="w-5 h-5 text-rose-600" />,
  Activity: <Activity className="w-5 h-5 text-blue-600" />,
  Baby: <Baby className="w-5 h-5 text-amber-600" />,
  Stethoscope: <Stethoscope className="w-5 h-5 text-teal-600" />,
  Brain: <Brain className="w-5 h-5 text-purple-600" />,
  Ear: <Ear className="w-5 h-5 text-sky-600" />,
  Sparkles: <Sparkles className="w-5 h-5 text-pink-600" />,
  UserCheck: <UserCheck className="w-5 h-5 text-emerald-600" />,
};

export const DepartmentDirectory: React.FC<DepartmentDirectoryProps> = ({
  departments,
  doctors,
  onSelectDepartment,
}) => {
  return (
    <div className="space-y-6">
      {/* Visual Hospital Facilities Split */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs flex flex-col sm:flex-row items-center">
          <div className="w-full sm:w-1/2 h-48 sm:h-full shrink-0">
            <img
              src="/src/assets/images/reception_counter_desk_1794246850339.jpg"
              alt="CareConnect OPD Reception Desk"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="p-6 space-y-2">
            <div className="text-[11px] font-bold text-sky-700 uppercase tracking-wider">
              Walk-in Reception Counters
            </div>
            <h3 className="font-bold text-base text-slate-900 leading-snug">
              Ground Floor Main OPD Lobby
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Counters 1–4 are equipped with synchronized token dispatchers to assist walk-in patients, verify previous visit records, and direct you to the consultation wings.
            </p>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs flex flex-col sm:flex-row items-center">
          <div className="w-full sm:w-1/2 h-48 sm:h-full shrink-0">
            <img
              src="/src/assets/images/doctor_consultation_opd_1794246850732.jpg"
              alt="Doctor Consultation OPD Room"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="p-6 space-y-2">
            <div className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider">
              Specialist Consultation
            </div>
            <h3 className="font-bold text-base text-slate-900 leading-snug">
              Consultation Suites & Diagnostics
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Board-certified specialists provide personalized evaluations across 8 dedicated clinical wings with direct access to in-house laboratory, radiology, and ECG stations.
            </p>
          </div>
        </div>
      </div>

      {/* Departments Directory Grid */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 md:p-8 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-100 pb-4">
          <div>
            <h3 className="text-base md:text-lg font-bold text-slate-900">
              Outpatient Specialty Clinics & Locations
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Click any department to begin booking an appointment with the consulting specialist
            </p>
          </div>
          <div className="text-xs text-slate-500 font-medium">
            Total 8 Active Specialty Wings
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {departments.map((dept) => {
            const docCount = doctors.filter((d) => d.departmentId === dept.id).length;
            const icon = DEPT_ICONS[dept.iconName] || (
              <Building2 className="w-5 h-5 text-sky-600" />
            );

            return (
              <div
                key={dept.id}
                onClick={() => onSelectDepartment(dept.id)}
                className="p-5 rounded-2xl border border-slate-200 bg-slate-50/60 hover:bg-sky-50/40 hover:border-sky-300 transition-all cursor-pointer group flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="p-2.5 bg-white rounded-xl shadow-2xs border border-slate-200/80 group-hover:scale-105 transition-transform">
                      {icon}
                    </div>
                    <span className="text-[10px] font-mono font-bold text-slate-500 bg-white px-2 py-0.5 rounded border border-slate-200">
                      {dept.code}
                    </span>
                  </div>

                  <div>
                    <h4 className="font-bold text-sm text-slate-900 group-hover:text-sky-800 transition-colors">
                      {dept.name}
                    </h4>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                      {dept.description}
                    </p>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-200/70 text-xs text-slate-600 flex items-center justify-between">
                  <span className="text-[11px] font-medium text-slate-500">
                    {dept.floor}
                  </span>
                  <span className="text-sky-700 font-semibold group-hover:translate-x-0.5 transition-transform flex items-center gap-1 text-[11px]">
                    <span>Book OP</span>
                    <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
