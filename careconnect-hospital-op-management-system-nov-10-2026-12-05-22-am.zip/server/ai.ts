import { GoogleGenAI, Type } from '@google/genai';
import { AISymptomSuggestion } from '../src/types/index.js';

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const DEPARTMENT_LOOKUP: Record<string, { id: string; name: string }> = {
  cardiology: { id: 'dep-cardio', name: 'Cardiology' },
  orthopedics: { id: 'dep-ortho', name: 'Orthopedics & Joint Care' },
  pediatrics: { id: 'dep-pedia', name: 'Pediatrics & Child Care' },
  generalmedicine: { id: 'dep-genmed', name: 'General Medicine' },
  neurology: { id: 'dep-neuro', name: 'Neurology' },
  ent: { id: 'dep-ent', name: 'ENT (Ear, Nose & Throat)' },
  dermatology: { id: 'dep-derma', name: 'Dermatology & Skin Care' },
  gynecology: { id: 'dep-gynae', name: 'Obstetrics & Gynecology' },
};

function getLocalRuleBasedSuggestion(
  symptoms: string,
  age?: number,
  gender?: string
): AISymptomSuggestion {
  const text = symptoms.toLowerCase();

  // Emergency red flags
  const isEmergency =
    /crushing chest|radiating to (left arm|jaw)|unconscious|severe sudden shortness of breath|facial droop|can't speak|stroke|vomiting blood|massive bleeding/.test(
      text
    );

  if (isEmergency) {
    return {
      suggestedDepartment: 'Cardiology',
      matchedDepartmentId: 'dep-cardio',
      explanation:
        'Your symptoms describe potential acute cardiac or urgent vascular symptoms. Please do not wait for a routine outpatient appointment if you are experiencing severe distress.',
      suggestedQuestions: [
        'When did this severe discomfort begin?',
        'Are there accompanying symptoms like sweating or shortness of breath?',
        'Do you have a personal or family history of cardiac conditions?',
      ],
      isUrgentCareNeeded: true,
      urgencyWarning:
        'CRITICAL ALERT: If experiencing severe chest pain, sudden numbness, or acute shortness of breath, proceed immediately to the CareConnect 24x7 Emergency Casualty Bay or dial emergency services (108 / 911).',
      disclaimer:
        'Notice: This AI recommendation is an automated triage tool to guide department selection only. It does NOT constitute medical diagnosis, treatment, or clinical advice.',
    };
  }

  // Pediatrics check
  if (age !== undefined && age < 16) {
    return {
      suggestedDepartment: 'Pediatrics & Child Care',
      matchedDepartmentId: 'dep-pedia',
      explanation:
        'For children and adolescents under 16 years, our specialized pediatric physicians assess childhood viral infections, developmental health, fevers, and immunization status.',
      suggestedQuestions: [
        'How many days has the fever or discomfort lasted?',
        'Is the child able to stay hydrated and eat normally?',
        'Are there any rash, cough, or breathing changes?',
      ],
      isUrgentCareNeeded: false,
      disclaimer:
        'Notice: This AI suggestion is not a medical diagnosis. Please consult a qualified pediatrician for clinical evaluation.',
    };
  }

  // Heart / chest
  if (/chest|heart|palpitation|high bp|hypertension|cholesterol|pulse/.test(text)) {
    return {
      suggestedDepartment: 'Cardiology',
      matchedDepartmentId: 'dep-cardio',
      explanation:
        'Cardiology specializes in cardiovascular symptoms, heart palpitations, blood pressure irregularities, and chest discomfort.',
      suggestedQuestions: [
        'Does the symptom worsen with physical exertion or climbing stairs?',
        'Have you checked your blood pressure recently?',
        'Are you currently taking any antihypertensive medications?',
      ],
      isUrgentCareNeeded: false,
      disclaimer:
        'Notice: This AI suggestion is not a medical diagnosis. Never take or stop prescription drugs without a doctor’s consultation.',
    };
  }

  // Ortho / bone / joint
  if (/bone|fracture|knee|joint|arthritis|back pain|spine|shoulder|ankle|sprain|swollen leg/.test(text)) {
    return {
      suggestedDepartment: 'Orthopedics & Joint Care',
      matchedDepartmentId: 'dep-ortho',
      explanation:
        'Orthopedics focuses on musculoskeletal health, joint mobility, bone injuries, arthritis, and back/spinal discomfort.',
      suggestedQuestions: [
        'Was there an acute injury or did the pain develop gradually over time?',
        'Does rest or cold/warm compression provide relief?',
        'Is there morning stiffness or restricted range of motion?',
      ],
      isUrgentCareNeeded: false,
      disclaimer:
        'Notice: This AI suggestion is not a medical diagnosis. Consult an orthopedic specialist for physical and radiological examination.',
    };
  }

  // Neuro
  if (/headache|migraine|dizzy|vertigo|numbness|tingling|seizure|tremor|memory/.test(text)) {
    return {
      suggestedDepartment: 'Neurology',
      matchedDepartmentId: 'dep-neuro',
      explanation:
        'Neurology specializes in headaches, nerve pathways, migraines, balance difficulties, and sensory issues.',
      suggestedQuestions: [
        'How frequently do the headaches or sensations occur?',
        'Are they triggered by light, sound, or stress?',
        'Have you noticed any changes in vision or balance?',
      ],
      isUrgentCareNeeded: false,
      disclaimer:
        'Notice: This AI suggestion is not a medical diagnosis. A doctor will conduct neurological reflex and sensory tests.',
    };
  }

  // ENT
  if (/ear|throat|tonsil|sinus|nasal|nose|hearing|hoarse|phlegm|sore throat/.test(text)) {
    return {
      suggestedDepartment: 'ENT (Ear, Nose & Throat)',
      matchedDepartmentId: 'dep-ent',
      explanation:
        'ENT specialists diagnose upper respiratory tract symptoms, nasal congestion, sinus pressure, ear drainage, and vocal cord hoarseness.',
      suggestedQuestions: [
        'Is there any discharge or pain in either ear?',
        'How long have nasal congestion or throat symptoms persisted?',
        'Do you experience seasonal allergies or snoring?',
      ],
      isUrgentCareNeeded: false,
      disclaimer:
        'Notice: This AI suggestion is not a medical diagnosis. Consult an ENT specialist for endoscopic inspection.',
    };
  }

  // Dermatology
  if (/skin|rash|itch|acne|eczema|allergy|blister|hair loss|scalp|nail/.test(text)) {
    return {
      suggestedDepartment: 'Dermatology & Skin Care',
      matchedDepartmentId: 'dep-derma',
      explanation:
        'Dermatology addresses skin dermatoses, allergic rashes, eczema flare-ups, acne, and hair or nail conditions.',
      suggestedQuestions: [
        'Has there been contact with any new skincare products or detergents?',
        'Does the rash itch, burn, or spread to other parts of the body?',
        'Have you had previous allergic episodes?',
      ],
      isUrgentCareNeeded: false,
      disclaimer:
        'Notice: This AI suggestion is not a medical diagnosis. Never self-apply prescription steroids without doctor guidance.',
    };
  }

  // Gynecology
  if (
    gender === 'Female' &&
    /period|menstrual|pregnancy|pregnant|cramp|ovary|pcod|pcos|pelvic/.test(text)
  ) {
    return {
      suggestedDepartment: 'Obstetrics & Gynecology',
      matchedDepartmentId: 'dep-gynae',
      explanation:
        'Obstetrics & Gynecology provides comprehensive care for women’s reproductive health, prenatal monitoring, hormonal regulation, and pelvic wellness.',
      suggestedQuestions: [
        'What was the date of your last menstrual period?',
        'Are your cycles regular or accompanied by severe cramping?',
        'Are there any plans for prenatal screening or routine checks?',
      ],
      isUrgentCareNeeded: false,
      disclaimer:
        'Notice: This AI suggestion is not a medical diagnosis. Consult a gynecologist for personalized clinical care.',
    };
  }

  // Default: General Medicine
  return {
    suggestedDepartment: 'General Medicine',
    matchedDepartmentId: 'dep-genmed',
    explanation:
      'General Medicine is the primary adult OPD department for comprehensive initial evaluation, fever investigation, fatigue, chronic illness monitoring, and general health review.',
    suggestedQuestions: [
      'How long have you noticed these symptoms?',
      'Are you experiencing accompanying fever, fatigue, or appetite loss?',
      'Do you have any existing chronic conditions like diabetes or thyroid disorder?',
    ],
    isUrgentCareNeeded: false,
    disclaimer:
      'Notice: This AI suggestion is an automated hospital routing recommendation. It is NOT a medical diagnosis and never prescribes medication.',
  };
}

export async function suggestDepartmentWithAI(
  symptoms: string,
  age?: number,
  gender?: string
): Promise<AISymptomSuggestion> {
  const fallback = getLocalRuleBasedSuggestion(symptoms, age, gender);

  if (!process.env.GEMINI_API_KEY) {
    return fallback;
  }

  try {
    const prompt = `A hospital outpatient has entered the following health symptoms to help choose the right hospital outpatient department:
Symptoms: "${symptoms}"
Patient Age: ${age !== undefined ? age : 'Not specified'}
Patient Gender: ${gender || 'Not specified'}

Hospital Available Departments:
- "Cardiology" (Heart health, chest discomfort, palpitations, hypertension, arrhythmias) -> id: dep-cardio
- "Orthopedics & Joint Care" (Bone injuries, arthritis, joints, back/spine pain, fractures) -> id: dep-ortho
- "Pediatrics & Child Care" (Infants, children & teens under 16, pediatric infections, growth) -> id: dep-pedia
- "General Medicine" (Fever, fatigue, viral illnesses, diabetes, adult primary care) -> id: dep-genmed
- "Neurology" (Headaches, migraines, dizziness, numbness, nerve pain, seizures) -> id: dep-neuro
- "ENT (Ear, Nose & Throat)" (Sinusitis, ear discharge, hearing issues, sore throat) -> id: dep-ent
- "Dermatology & Skin Care" (Skin rashes, itching, acne, eczema, hair & nail disorders) -> id: dep-derma
- "Obstetrics & Gynecology" (Women's health, menstrual cycles, prenatal care, PCOD) -> id: dep-gynae

CRITICAL INSTRUCTIONS:
1. You are an outpatient triage navigation guide. You are NOT diagnosing the patient.
2. NEVER prescribe medicines, drugs, or specific dosages.
3. Suggest the single best-matched department from the above 8 departments.
4. If symptoms sound like a life-threatening emergency (e.g. crushing chest pain, signs of stroke, extreme breathing distress), set isUrgentCareNeeded to true and provide a clear warning.
5. Provide 2 to 3 concise questions the patient should prepare to ask their doctor in OPD.
6. Provide a clear disclaimer that this is only an OP navigation suggestion, not a diagnosis.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction:
          'You are CareConnect Hospital’s triage assistant. Help patients select the appropriate outpatient specialty clinic based on described symptoms. Never provide a clinical diagnosis or prescribe medicines.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            suggestedDepartment: {
              type: Type.STRING,
              description: 'Exact name of the suggested department',
            },
            departmentCode: {
              type: Type.STRING,
              description: 'One of: dep-cardio, dep-ortho, dep-pedia, dep-genmed, dep-neuro, dep-ent, dep-derma, dep-gynae',
            },
            explanation: {
              type: Type.STRING,
              description: 'Brief, compassionate explanation of why this clinic is recommended (2-3 sentences)',
            },
            suggestedQuestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '2 to 3 helpful questions the patient can ask their doctor',
            },
            isUrgentCareNeeded: {
              type: Type.BOOLEAN,
              description: 'True if symptoms suggest acute emergency needing emergency room care immediately',
            },
            urgencyWarning: {
              type: Type.STRING,
              description: 'Emergency warning message if urgent care is needed',
            },
            disclaimer: {
              type: Type.STRING,
              description: 'Medical disclaimer confirming this is routing advice, not diagnosis or prescription',
            },
          },
          required: [
            'suggestedDepartment',
            'departmentCode',
            'explanation',
            'suggestedQuestions',
            'isUrgentCareNeeded',
            'disclaimer',
          ],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    if (parsed.suggestedDepartment && parsed.departmentCode) {
      return {
        suggestedDepartment: parsed.suggestedDepartment,
        matchedDepartmentId: parsed.departmentCode,
        explanation: parsed.explanation,
        suggestedQuestions: parsed.suggestedQuestions || fallback.suggestedQuestions,
        isUrgentCareNeeded: Boolean(parsed.isUrgentCareNeeded),
        urgencyWarning: parsed.urgencyWarning,
        disclaimer:
          parsed.disclaimer ||
          'Notice: This AI recommendation is an automated triage tool to guide department selection only. It does NOT constitute medical diagnosis, treatment, or clinical advice.',
      };
    }

    return fallback;
  } catch (error) {
    console.error('Gemini API call failed, using rule-based triage fallback:', error);
    return fallback;
  }
}
