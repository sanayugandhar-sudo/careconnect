import fs from 'fs';
import path from 'path';
import {
  Department,
  Doctor,
  HospitalInfo,
  OPRegistration,
  Patient,
  StaffUser,
  DashboardStats,
  RegistrationStatus,
} from '../src/types/index.js';

interface DatabaseSchema {
  hospitalInfo: HospitalInfo;
  departments: Department[];
  doctors: Doctor[];
  patients: Patient[];
  registrations: OPRegistration[];
  staff: (StaffUser & { passwordHash: string })[];
  sessions: Record<string, StaffUser>;
  sequences: {
    opNumberSequence: number;
    patientSequence: number;
  };
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.resolve(DATA_DIR, 'careconnect_db.json');

// Concurrency lock queue to ensure safe sequential atomic state updates
let queuePromise: Promise<void> = Promise.resolve();

function withLock<T>(action: () => Promise<T> | T): Promise<T> {
  const resultPromise = queuePromise.then(async () => {
    return await action();
  });
  queuePromise = resultPromise.then(() => {}, () => {});
  return resultPromise;
}

const DEFAULT_HOSPITAL_INFO: HospitalInfo = {
  name: 'CareConnect Multispeciality Hospital',
  tagline: 'Center for Compassionate Care & Clinical Excellence',
  address: '450 Health Sciences Parkway, Medi-City District',
  cityStateZip: 'Metro City, MC 500081',
  helpline: '+1 (800) 555-CARE / 040-6789-4000',
  emergency: '24x7 Emergency Helpline: 108 / 040-6789-9999',
  email: 'opd.reception@careconnect-demo.org',
  opdHours: 'Mon - Sat: 8:30 AM - 8:00 PM | Sun: 9:00 AM - 1:00 PM',
  counterLocations: 'Counters 1 to 4: Ground Floor Main Lobby | Counter 5: Emergency Reception',
};

const DEFAULT_DEPARTMENTS: Department[] = [
  {
    id: 'dep-genmed',
    name: 'General Medicine',
    code: 'GM',
    description: 'Fever, chronic conditions, diabetes, infections, health checkups and adult primary care.',
    floor: 'Ground Floor',
    wing: 'OPD Wing A',
    headDoctor: 'Dr. Robert Vance, MD',
    iconName: 'Stethoscope',
    active: true,
  },
  {
    id: 'dep-cardio',
    name: 'Cardiology',
    code: 'CARD',
    description: 'Heart health, chest pain, hypertension, arrhythmias, ECG, echocardiography and preventive cardiology.',
    floor: '2nd Floor',
    wing: 'Heart & Vascular Center',
    headDoctor: 'Dr. Sarah Jenkins, MD, FACC',
    iconName: 'HeartPulse',
    active: true,
  },
  {
    id: 'dep-ortho',
    name: 'Orthopedics & Joint Care',
    code: 'ORTH',
    description: 'Bone fractures, arthritis, joint replacements, spinal disorders and sports injury rehab.',
    floor: '1st Floor',
    wing: 'Bone & Joint Wing',
    headDoctor: 'Dr. Marcus Thorne, MS (Ortho)',
    iconName: 'Activity',
    active: true,
  },
  {
    id: 'dep-pedia',
    name: 'Pediatrics & Child Care',
    code: 'PED',
    description: 'Infant wellness, pediatric immunizations, childhood infections, growth and developmental checkups.',
    floor: '3rd Floor',
    wing: 'Mother & Child Pavilion',
    headDoctor: 'Dr. Elena Rostova, MD (Pediatrics)',
    iconName: 'Baby',
    active: true,
  },
  {
    id: 'dep-neuro',
    name: 'Neurology',
    code: 'NEUR',
    description: 'Headaches, migraines, nerve pain, stroke management, neuropathy, tremors and epilepsy care.',
    floor: '2nd Floor',
    wing: 'Neurosciences Block',
    headDoctor: 'Dr. Anand Iyer, DM (Neuro)',
    iconName: 'Brain',
    active: true,
  },
  {
    id: 'dep-ent',
    name: 'ENT (Ear, Nose & Throat)',
    code: 'ENT',
    description: 'Sinusitis, ear discharge, hearing difficulties, tonsillitis, vertigo and nasal allergies.',
    floor: '1st Floor',
    wing: 'Sensory Health Wing',
    headDoctor: 'Dr. Chloe Mitchell, MS (ENT)',
    iconName: 'Ear',
    active: true,
  },
  {
    id: 'dep-derma',
    name: 'Dermatology & Skin Care',
    code: 'DERM',
    description: 'Skin rashes, acne, psoriasis, eczema, hair loss, nail disorders and skin allergy management.',
    floor: 'Ground Floor',
    wing: 'Wing C',
    headDoctor: 'Dr. Priya Sundaram, MD (Derm)',
    iconName: 'Sparkles',
    active: true,
  },
  {
    id: 'dep-gynae',
    name: 'Obstetrics & Gynecology',
    code: 'GYN',
    description: 'Women health, prenatal maternal care, menstrual disorders, PCOD, and menopausal wellness.',
    floor: '3rd Floor',
    wing: 'Mother & Child Pavilion',
    headDoctor: 'Dr. Anita Desai, MS (OB-GYN)',
    iconName: 'UserCheck',
    active: true,
  },
];

const STANDARD_SLOTS = [
  '09:00 AM',
  '09:30 AM',
  '10:00 AM',
  '10:30 AM',
  '11:00 AM',
  '11:30 AM',
  '12:00 PM',
  '12:30 PM',
  '02:00 PM',
  '02:30 PM',
  '03:00 PM',
  '03:30 PM',
  '04:00 PM',
  '04:30 PM',
  '05:00 PM',
  '05:30 PM',
];

const DEFAULT_DOCTORS: Doctor[] = [
  {
    id: 'doc-jenkins',
    name: 'Dr. Sarah Jenkins',
    qualification: 'MD, DM (Cardiology), FACC',
    departmentId: 'dep-cardio',
    departmentName: 'Cardiology',
    specialization: 'Interventional Cardiology & Preventive Heart Health',
    experienceYears: 16,
    roomNumber: 'Room 204',
    floor: '2nd Floor, Heart Wing',
    consultationFee: 500,
    opdDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    opdTimings: '09:00 AM - 01:30 PM | 04:00 PM - 06:30 PM',
    availableSlots: STANDARD_SLOTS,
    isAvailable: true,
  },
  {
    id: 'doc-thorne',
    name: 'Dr. Marcus Thorne',
    qualification: 'MS (Orthopedics), M.Ch (Joint Replacement)',
    departmentId: 'dep-ortho',
    departmentName: 'Orthopedics & Joint Care',
    specialization: 'Total Knee/Hip Replacement, Spine & Trauma Care',
    experienceYears: 14,
    roomNumber: 'Room 112',
    floor: '1st Floor, Bone & Joint Wing',
    consultationFee: 450,
    opdDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
    opdTimings: '09:30 AM - 02:00 PM | 03:30 PM - 06:00 PM',
    availableSlots: STANDARD_SLOTS,
    isAvailable: true,
  },
  {
    id: 'doc-vance',
    name: 'Dr. Robert Vance',
    qualification: 'MD (Internal Medicine), FACP',
    departmentId: 'dep-genmed',
    departmentName: 'General Medicine',
    specialization: 'Adult Chronic Illnesses, Fever Evaluation, Diabetology',
    experienceYears: 20,
    roomNumber: 'Room 102',
    floor: 'Ground Floor, Main OPD',
    consultationFee: 350,
    opdDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    opdTimings: '08:30 AM - 01:00 PM | 03:00 PM - 07:00 PM',
    availableSlots: STANDARD_SLOTS,
    isAvailable: true,
  },
  {
    id: 'doc-rostova',
    name: 'Dr. Elena Rostova',
    qualification: 'MD (Pediatrics), DNB, Fellowship in Neonatology',
    departmentId: 'dep-pedia',
    departmentName: 'Pediatrics & Child Care',
    specialization: 'Pediatric Infectious Diseases & Developmental Health',
    experienceYears: 11,
    roomNumber: 'Room 305',
    floor: '3rd Floor, Child Care Wing',
    consultationFee: 400,
    opdDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    opdTimings: '09:00 AM - 01:00 PM | 04:00 PM - 06:30 PM',
    availableSlots: STANDARD_SLOTS,
    isAvailable: true,
  },
  {
    id: 'doc-iyer',
    name: 'Dr. Anand Iyer',
    qualification: 'MBBS, MD, DM (Neurology)',
    departmentId: 'dep-neuro',
    departmentName: 'Neurology',
    specialization: 'Migraine, Epilepsy, Peripheral Neuropathy, Parkinsonism',
    experienceYears: 15,
    roomNumber: 'Room 210',
    floor: '2nd Floor, Neuro Center',
    consultationFee: 600,
    opdDays: ['Mon', 'Wed', 'Fri', 'Sat'],
    opdTimings: '10:00 AM - 02:00 PM | 04:00 PM - 06:00 PM',
    availableSlots: STANDARD_SLOTS,
    isAvailable: true,
  },
  {
    id: 'doc-mitchell',
    name: 'Dr. Chloe Mitchell',
    qualification: 'MS (ENT), DLO',
    departmentId: 'dep-ent',
    departmentName: 'ENT (Ear, Nose & Throat)',
    specialization: 'Endoscopic Sinus Surgery, Hearing & Vertigo Disorders',
    experienceYears: 9,
    roomNumber: 'Room 118',
    floor: '1st Floor, Wing A',
    consultationFee: 400,
    opdDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    opdTimings: '09:00 AM - 01:00 PM | 03:00 PM - 05:30 PM',
    availableSlots: STANDARD_SLOTS,
    isAvailable: true,
  },
  {
    id: 'doc-sundaram',
    name: 'Dr. Priya Sundaram',
    qualification: 'MD (Dermatology, Venereology & Leprosy)',
    departmentId: 'dep-derma',
    departmentName: 'Dermatology & Skin Care',
    specialization: 'Clinical Dermatology, Eczema, Acne & Laser Therapy',
    experienceYears: 12,
    roomNumber: 'Room 108',
    floor: 'Ground Floor, Wing C',
    consultationFee: 450,
    opdDays: ['Tue', 'Thu', 'Fri', 'Sat'],
    opdTimings: '10:00 AM - 01:30 PM | 04:00 PM - 07:00 PM',
    availableSlots: STANDARD_SLOTS,
    isAvailable: true,
  },
  {
    id: 'doc-desai',
    name: 'Dr. Anita Desai',
    qualification: 'MS (OB-GYN), DGO, FICOG',
    departmentId: 'dep-gynae',
    departmentName: 'Obstetrics & Gynecology',
    specialization: 'High-risk Pregnancy, Laparoscopic Surgery, Infertility',
    experienceYears: 18,
    roomNumber: 'Room 312',
    floor: '3rd Floor, Mother & Child Block',
    consultationFee: 500,
    opdDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
    opdTimings: '09:00 AM - 02:00 PM',
    availableSlots: STANDARD_SLOTS,
    isAvailable: true,
  },
];

const DEFAULT_STAFF: (StaffUser & { passwordHash: string })[] = [
  {
    id: 'staff-rec-1',
    name: 'Sarah Connor',
    email: 'receptionist@careconnect.org',
    role: 'receptionist',
    departmentAssigned: 'Main OP Reception Desk 1',
    passwordHash: 'rec123',
  },
  {
    id: 'staff-rec-2',
    name: 'David Miller',
    email: 'reception2@careconnect.org',
    role: 'receptionist',
    departmentAssigned: 'OP Counter 2',
    passwordHash: 'rec123',
  },
  {
    id: 'staff-adm-1',
    name: 'Dr. Evelyn Reed (Medical Superintendent)',
    email: 'admin@careconnect.org',
    role: 'admin',
    departmentAssigned: 'Hospital Administration',
    passwordHash: 'admin123',
  },
];

const DEFAULT_PATIENTS: Patient[] = [
  {
    id: 'PAT-1001',
    fullName: 'Emily Watson',
    age: 38,
    gender: 'Female',
    mobileNumber: '9876543210',
    address: 'Flat 402, Green Meadows, Health City',
    bloodGroup: 'B+',
    emergencyContact: '9876543211',
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
  },
  {
    id: 'PAT-1002',
    fullName: 'Rajesh Kumar Verma',
    age: 52,
    gender: 'Male',
    mobileNumber: '9811223344',
    address: 'Plot 18, Hill View Colony, Metro City',
    bloodGroup: 'O+',
    emergencyContact: '9811223345',
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: 'PAT-1003',
    fullName: 'Aarav Sharma',
    age: 7,
    gender: 'Male',
    mobileNumber: '9944332211',
    address: 'House 88, Lake Town, Metro City',
    bloodGroup: 'A+',
    emergencyContact: '9944332212',
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
  },
  {
    id: 'PAT-1004',
    fullName: 'Clara Fernandez',
    age: 44,
    gender: 'Female',
    mobileNumber: '9123456780',
    address: '22 Palm Grove Avenue, West District',
    bloodGroup: 'AB+',
    emergencyContact: '9123456781',
    createdAt: new Date().toISOString(),
  },
];

function getTodayString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function getInitialDemoRegistrations(): OPRegistration[] {
  const today = getTodayString();
  return [
    {
      id: 'reg-demo-1',
      opNumber: 'CC-2026-1001',
      tokenNumber: 1,
      patientId: 'PAT-1001',
      patientName: 'Emily Watson',
      age: 38,
      gender: 'Female',
      mobileNumber: '9876543210',
      address: 'Flat 402, Green Meadows, Health City',
      departmentId: 'dep-cardio',
      departmentName: 'Cardiology',
      doctorId: 'doc-jenkins',
      doctorName: 'Dr. Sarah Jenkins',
      roomNumber: 'Room 204',
      floor: '2nd Floor, Heart Wing',
      registrationType: 'online',
      appointmentDate: today,
      appointmentTime: '09:00 AM',
      registrationDate: new Date(Date.now() - 3600000 * 3).toISOString(),
      status: 'In Consultation',
      consultationFee: 500,
      paymentStatus: 'Online Confirmed',
      symptomsNotes: 'Mild chest heaviness upon brisk walking, history of high BP (DEMO).',
      registeredBy: 'patient_self',
      isDemo: true,
      arrivedAt: new Date(Date.now() - 3600000 * 1).toISOString(),
    },
    {
      id: 'reg-demo-2',
      opNumber: 'CC-2026-1002',
      tokenNumber: 2,
      patientId: 'PAT-1002',
      patientName: 'Rajesh Kumar Verma',
      age: 52,
      gender: 'Male',
      mobileNumber: '9811223344',
      address: 'Plot 18, Hill View Colony, Metro City',
      departmentId: 'dep-ortho',
      departmentName: 'Orthopedics & Joint Care',
      doctorId: 'doc-thorne',
      doctorName: 'Dr. Marcus Thorne',
      roomNumber: 'Room 112',
      floor: '1st Floor, Bone & Joint Wing',
      registrationType: 'walk-in',
      appointmentDate: today,
      appointmentTime: '09:30 AM',
      registrationDate: new Date(Date.now() - 3600000 * 2).toISOString(),
      status: 'Waiting',
      consultationFee: 450,
      paymentStatus: 'Paid at Counter',
      symptomsNotes: 'Right knee stiffness and acute swelling after morning walk (DEMO).',
      registeredBy: 'receptionist',
      isDemo: true,
      arrivedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    },
    {
      id: 'reg-demo-3',
      opNumber: 'CC-2026-1003',
      tokenNumber: 1,
      patientId: 'PAT-1003',
      patientName: 'Aarav Sharma',
      age: 7,
      gender: 'Male',
      mobileNumber: '9944332211',
      address: 'House 88, Lake Town, Metro City',
      departmentId: 'dep-pedia',
      departmentName: 'Pediatrics & Child Care',
      doctorId: 'doc-rostova',
      doctorName: 'Dr. Elena Rostova',
      roomNumber: 'Room 305',
      floor: '3rd Floor, Child Care Wing',
      registrationType: 'online',
      appointmentDate: today,
      appointmentTime: '10:00 AM',
      registrationDate: new Date(Date.now() - 3600000 * 4).toISOString(),
      status: 'Completed',
      consultationFee: 400,
      paymentStatus: 'Online Confirmed',
      symptomsNotes: 'Pediatric viral fever follow-up & routine immunization check (DEMO).',
      registeredBy: 'patient_self',
      isDemo: true,
      completedAt: new Date(Date.now() - 1800000).toISOString(),
    },
    {
      id: 'reg-demo-4',
      opNumber: 'CC-2026-1004',
      tokenNumber: 1,
      patientId: 'PAT-1004',
      patientName: 'Clara Fernandez',
      age: 44,
      gender: 'Female',
      mobileNumber: '9123456780',
      address: '22 Palm Grove Avenue, West District',
      departmentId: 'dep-genmed',
      departmentName: 'General Medicine',
      doctorId: 'doc-vance',
      doctorName: 'Dr. Robert Vance',
      roomNumber: 'Room 102',
      floor: 'Ground Floor, Main OPD',
      registrationType: 'walk-in',
      appointmentDate: today,
      appointmentTime: '10:30 AM',
      registrationDate: new Date(Date.now() - 1800000).toISOString(),
      status: 'Registered',
      consultationFee: 350,
      paymentStatus: 'Paid at Counter',
      symptomsNotes: 'Routine executive health blood sugar check & seasonal cough (DEMO).',
      registeredBy: 'receptionist',
      isDemo: true,
    },
  ];
}

class PersistentDatabase {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.loadDatabase();
  }

  private loadDatabase(): DatabaseSchema {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }

      if (fs.existsSync(DB_FILE)) {
        const fileContent = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(fileContent);
        return {
          hospitalInfo: parsed.hospitalInfo || DEFAULT_HOSPITAL_INFO,
          departments: parsed.departments || DEFAULT_DEPARTMENTS,
          doctors: parsed.doctors || DEFAULT_DOCTORS,
          patients: parsed.patients || DEFAULT_PATIENTS,
          registrations: parsed.registrations || getInitialDemoRegistrations(),
          staff: parsed.staff || DEFAULT_STAFF,
          sessions: parsed.sessions || {},
          sequences: parsed.sequences || { opNumberSequence: 1005, patientSequence: 1005 },
        };
      }
    } catch (err) {
      console.error('Error loading database file, initializing defaults:', err);
    }

    const defaultState: DatabaseSchema = {
      hospitalInfo: DEFAULT_HOSPITAL_INFO,
      departments: DEFAULT_DEPARTMENTS,
      doctors: DEFAULT_DOCTORS,
      patients: DEFAULT_PATIENTS,
      registrations: getInitialDemoRegistrations(),
      staff: DEFAULT_STAFF,
      sessions: {},
      sequences: {
        opNumberSequence: 1005,
        patientSequence: 1005,
      },
    };
    this.saveDirect(defaultState);
    return defaultState;
  }

  private saveDirect(dataToSave: DatabaseSchema) {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const tempFile = `${DB_FILE}.tmp.${Date.now()}`;
    fs.writeFileSync(tempFile, JSON.stringify(dataToSave, null, 2), 'utf-8');
    fs.renameSync(tempFile, DB_FILE);
  }

  public async save(): Promise<void> {
    return withLock(() => {
      this.saveDirect(this.data);
    });
  }

  public getHospitalInfo(): HospitalInfo {
    return this.data.hospitalInfo;
  }

  public getDepartments(): Department[] {
    return this.data.departments;
  }

  public getDoctors(departmentId?: string): Doctor[] {
    if (departmentId) {
      return this.data.doctors.filter(
        (doc) => doc.departmentId === departmentId && doc.isAvailable
      );
    }
    return this.data.doctors;
  }

  public getDoctorById(doctorId: string): Doctor | undefined {
    return this.data.doctors.find((d) => d.id === doctorId);
  }

  public updateDoctor(doctorId: string, updates: Partial<Doctor>): Doctor | null {
    const doc = this.data.doctors.find((d) => d.id === doctorId);
    if (!doc) return null;
    Object.assign(doc, updates);
    this.saveDirect(this.data);
    return doc;
  }

  public addDoctor(doctorData: Omit<Doctor, 'id'>): Doctor {
    const newId = `doc-${Date.now()}`;
    const newDoc: Doctor = {
      ...doctorData,
      id: newId,
    };
    this.data.doctors.push(newDoc);
    this.saveDirect(this.data);
    return newDoc;
  }

  public deleteDoctor(doctorId: string): boolean {
    const index = this.data.doctors.findIndex((d) => d.id === doctorId);
    if (index === -1) return false;
    this.data.doctors.splice(index, 1);
    this.saveDirect(this.data);
    return true;
  }

  public addDepartment(deptData: Omit<Department, 'id'>): Department {
    const newId = `dep-${Date.now()}`;
    const newDept: Department = {
      ...deptData,
      id: newId,
      active: true,
    };
    this.data.departments.push(newDept);
    this.saveDirect(this.data);
    return newDept;
  }

  public updateDepartment(departmentId: string, updates: Partial<Department>): Department | null {
    const dept = this.data.departments.find((d) => d.id === departmentId);
    if (!dept) return null;
    Object.assign(dept, updates);
    this.saveDirect(this.data);
    return dept;
  }

  public deleteDepartment(departmentId: string): boolean {
    const index = this.data.departments.findIndex((d) => d.id === departmentId);
    if (index === -1) return false;
    this.data.departments.splice(index, 1);
    this.saveDirect(this.data);
    return true;
  }

  public findPatientByMobile(mobileNumber: string): Patient | undefined {
    const cleanMobile = mobileNumber.replace(/\D/g, '');
    return this.data.patients.find((p) => p.mobileNumber.replace(/\D/g, '') === cleanMobile);
  }

  public searchPatients(query: string): Patient[] {
    const q = query.trim().toLowerCase();
    if (!q) return this.data.patients.slice(0, 10);
    return this.data.patients.filter(
      (p) =>
        p.fullName.toLowerCase().includes(q) ||
        p.mobileNumber.includes(q) ||
        p.id.toLowerCase().includes(q)
    );
  }

  public async getOrCreatePatient(
    patientData: {
      fullName: string;
      age: number;
      gender: Patient['gender'];
      mobileNumber: string;
      address: string;
      bloodGroup?: string;
      emergencyContact?: string;
    }
  ): Promise<Patient> {
    return withLock(() => {
      const existing = this.findPatientByMobile(patientData.mobileNumber);
      if (existing) {
        // Update details if provided
        existing.fullName = patientData.fullName;
        existing.age = patientData.age;
        existing.gender = patientData.gender;
        existing.address = patientData.address;
        if (patientData.bloodGroup) existing.bloodGroup = patientData.bloodGroup;
        if (patientData.emergencyContact) existing.emergencyContact = patientData.emergencyContact;
        this.saveDirect(this.data);
        return existing;
      }

      const nextId = `PAT-${this.data.sequences.patientSequence++}`;
      const newPatient: Patient = {
        id: nextId,
        fullName: patientData.fullName,
        age: patientData.age,
        gender: patientData.gender,
        mobileNumber: patientData.mobileNumber,
        address: patientData.address,
        bloodGroup: patientData.bloodGroup,
        emergencyContact: patientData.emergencyContact,
        createdAt: new Date().toISOString(),
      };
      this.data.patients.push(newPatient);
      this.saveDirect(this.data);
      return newPatient;
    });
  }

  public getBookedSlotsForDoctor(doctorId: string, date: string): string[] {
    return this.data.registrations
      .filter(
        (r) =>
          r.doctorId === doctorId &&
          r.appointmentDate === date &&
          r.status !== 'Cancelled'
      )
      .map((r) => r.appointmentTime);
  }

  public async registerOP(params: {
    patientDetails: {
      fullName: string;
      age: number;
      gender: Patient['gender'];
      mobileNumber: string;
      address: string;
      bloodGroup?: string;
    };
    departmentId: string;
    doctorId: string;
    appointmentDate: string; // YYYY-MM-DD
    appointmentTime: string; // e.g. "09:30 AM"
    registrationType: 'online' | 'walk-in';
    registeredBy: 'patient_self' | 'receptionist' | 'admin';
    symptomsNotes?: string;
    initialStatus?: RegistrationStatus;
    paymentStatus?: OPRegistration['paymentStatus'];
  }): Promise<OPRegistration> {
    return withLock(async () => {
      const department = this.data.departments.find((d) => d.id === params.departmentId);
      const doctor = this.data.doctors.find((d) => d.id === params.doctorId);

      if (!department || !doctor) {
        throw new Error('Invalid department or doctor specified');
      }

      // Check for slot collision on same doctor and date for scheduled online slots
      if (
        params.registrationType === 'online' &&
        params.appointmentTime &&
        !params.appointmentTime.startsWith('Walk-in')
      ) {
        const existingSlot = this.data.registrations.find(
          (r) =>
            r.doctorId === params.doctorId &&
            r.appointmentDate === params.appointmentDate &&
            r.appointmentTime === params.appointmentTime &&
            r.status !== 'Cancelled'
        );
        if (existingSlot) {
          throw new Error(
            `Appointment time slot ${params.appointmentTime} is already booked for ${doctor.name}. Please select an adjacent time slot.`
          );
        }
      }

      // Safe monotonic token sequence per doctor per date
      const doctorDateRegistrations = this.data.registrations.filter(
        (r) => r.doctorId === params.doctorId && r.appointmentDate === params.appointmentDate
      );
      let maxToken = 0;
      for (const reg of doctorDateRegistrations) {
        if (reg.tokenNumber > maxToken) {
          maxToken = reg.tokenNumber;
        }
      }
      const tokenNumber = maxToken + 1;

      // Safe monotonic unique OP Number (e.g., CC-2026-1045)
      const currentYear = new Date().getFullYear();
      const opSequence = this.data.sequences.opNumberSequence++;
      const opNumber = `CC-${currentYear}-${opSequence}`;

      // Get or create persistent patient profile
      let patient = this.findPatientByMobile(params.patientDetails.mobileNumber);
      if (!patient) {
        const nextPatId = `PAT-${this.data.sequences.patientSequence++}`;
        patient = {
          id: nextPatId,
          fullName: params.patientDetails.fullName,
          age: params.patientDetails.age,
          gender: params.patientDetails.gender,
          mobileNumber: params.patientDetails.mobileNumber,
          address: params.patientDetails.address,
          bloodGroup: params.patientDetails.bloodGroup,
          createdAt: new Date().toISOString(),
        };
        this.data.patients.push(patient);
      } else {
        // Keep updated
        patient.fullName = params.patientDetails.fullName;
        patient.age = params.patientDetails.age;
        patient.address = params.patientDetails.address;
      }

      const initialStatus: RegistrationStatus =
        params.initialStatus || (params.registrationType === 'walk-in' ? 'Waiting' : 'Registered');

      const registration: OPRegistration = {
        id: `reg-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        opNumber,
        tokenNumber,
        patientId: patient.id,
        patientName: patient.fullName,
        age: patient.age,
        gender: patient.gender,
        mobileNumber: patient.mobileNumber,
        address: patient.address,
        departmentId: department.id,
        departmentName: department.name,
        doctorId: doctor.id,
        doctorName: doctor.name,
        roomNumber: doctor.roomNumber,
        floor: doctor.floor,
        registrationType: params.registrationType,
        appointmentDate: params.appointmentDate,
        appointmentTime: params.appointmentTime,
        registrationDate: new Date().toISOString(),
        status: initialStatus,
        consultationFee: doctor.consultationFee,
        paymentStatus:
          params.paymentStatus ||
          (params.registrationType === 'walk-in' ? 'Paid at Counter' : 'Online Confirmed'),
        symptomsNotes: params.symptomsNotes || '',
        registeredBy: params.registeredBy,
        isDemo: true,
        arrivedAt: params.registrationType === 'walk-in' ? new Date().toISOString() : undefined,
      };

      this.data.registrations.unshift(registration);
      this.saveDirect(this.data);

      return registration;
    });
  }

  public lookupRegistration(opNumber: string, mobileNumber: string): OPRegistration | null {
    const cleanOp = opNumber.trim().toUpperCase();
    const cleanMobile = mobileNumber.replace(/\D/g, '');

    const record = this.data.registrations.find(
      (r) =>
        r.opNumber.toUpperCase() === cleanOp &&
        r.mobileNumber.replace(/\D/g, '') === cleanMobile
    );

    return record || null;
  }

  public getRegistrations(filters?: {
    date?: string;
    departmentId?: string;
    doctorId?: string;
    status?: RegistrationStatus;
    type?: 'online' | 'walk-in';
    search?: string;
  }): OPRegistration[] {
    let list = [...this.data.registrations];

    if (filters?.date) {
      list = list.filter((r) => r.appointmentDate === filters.date);
    }
    if (filters?.departmentId) {
      list = list.filter((r) => r.departmentId === filters.departmentId);
    }
    if (filters?.doctorId) {
      list = list.filter((r) => r.doctorId === filters.doctorId);
    }
    if (filters?.status) {
      list = list.filter((r) => r.status === filters.status);
    }
    if (filters?.type) {
      list = list.filter((r) => r.registrationType === filters.type);
    }
    if (filters?.search) {
      const q = filters.search.trim().toLowerCase();
      list = list.filter(
        (r) =>
          r.opNumber.toLowerCase().includes(q) ||
          r.patientName.toLowerCase().includes(q) ||
          r.mobileNumber.includes(q)
      );
    }

    return list;
  }

  public async updateRegistrationStatus(
    id: string,
    newStatus: RegistrationStatus
  ): Promise<OPRegistration | null> {
    return withLock(() => {
      const reg = this.data.registrations.find((r) => r.id === id);
      if (!reg) return null;

      reg.status = newStatus;
      if (newStatus === 'Waiting' && !reg.arrivedAt) {
        reg.arrivedAt = new Date().toISOString();
      }
      if (newStatus === 'Completed') {
        reg.completedAt = new Date().toISOString();
      }

      this.saveDirect(this.data);
      return reg;
    });
  }

  public getDashboardStats(): DashboardStats {
    const today = getTodayString();
    const all = this.data.registrations;
    const todayList = all.filter((r) => r.appointmentDate === today);

    const departmentCounts = this.data.departments.map((dept) => ({
      departmentId: dept.id,
      departmentName: dept.name,
      count: todayList.filter((r) => r.departmentId === dept.id).length,
    }));

    const doctorQueues = this.data.doctors.map((doc) => {
      const docToday = todayList.filter((r) => r.doctorId === doc.id);
      const waiting = docToday.filter((r) => r.status === 'Waiting').length;
      const inConsult = docToday.filter((r) => r.status === 'In Consultation');
      const completed = docToday.filter((r) => r.status === 'Completed').length;
      const currentToken = inConsult.length > 0 ? inConsult[0].tokenNumber : undefined;

      return {
        doctorId: doc.id,
        doctorName: doc.name,
        departmentName: doc.departmentName,
        roomNumber: doc.roomNumber,
        totalToday: docToday.length,
        waiting,
        inConsultation: inConsult.length,
        completed,
        currentToken,
      };
    });

    return {
      totalRegistrations: all.length,
      todayRegistrations: todayList.length,
      onlineRegistrations: todayList.filter((r) => r.registrationType === 'online').length,
      walkinRegistrations: todayList.filter((r) => r.registrationType === 'walk-in').length,
      waitingCount: todayList.filter((r) => r.status === 'Waiting').length,
      inConsultationCount: todayList.filter((r) => r.status === 'In Consultation').length,
      completedCount: todayList.filter((r) => r.status === 'Completed').length,
      cancelledCount: todayList.filter((r) => r.status === 'Cancelled').length,
      departmentCounts,
      doctorQueues,
    };
  }

  public authenticateStaff(email: string, passwordPlain: string): StaffUser | null {
    const user = this.data.staff.find(
      (s) => s.email.toLowerCase() === email.trim().toLowerCase()
    );
    if (!user) return null;
    if (user.passwordHash !== passwordPlain) return null;

    return {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      departmentAssigned: user.departmentAssigned,
    };
  }

  public createSession(token: string, user: StaffUser): void {
    if (!this.data.sessions) {
      this.data.sessions = {};
    }
    this.data.sessions[token] = user;
    this.saveDirect(this.data);
  }

  public getSession(token: string): StaffUser | null {
    return this.data.sessions?.[token] || null;
  }

  public deleteSession(token: string): void {
    if (this.data.sessions && this.data.sessions[token]) {
      delete this.data.sessions[token];
      this.saveDirect(this.data);
    }
  }

  public resetDemoData() {
    this.data = {
      hospitalInfo: DEFAULT_HOSPITAL_INFO,
      departments: DEFAULT_DEPARTMENTS,
      doctors: DEFAULT_DOCTORS,
      patients: DEFAULT_PATIENTS,
      registrations: getInitialDemoRegistrations(),
      staff: DEFAULT_STAFF,
      sessions: {},
      sequences: {
        opNumberSequence: 1005,
        patientSequence: 1005,
      },
    };
    this.saveDirect(this.data);
  }
}

export const db = new PersistentDatabase();
